package com.example.sample;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

@DynamoDBTable(tableName = "Farm1")
public class mapperfarm1 {
    String Id;
    String sensordata;

    @DynamoDBHashKey(attributeName="Id")
    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    @DynamoDBAttribute(attributeName="Ontime")
    public String getSensordata() {
        return sensordata;
    }

    public void setOntime(String Ontime) {
        this.sensordata = sensordata;
    }

}
