package com.example.sample;

//from pubsub
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttClientStatusCallback;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttManager;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttNewMessageCallback;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttQos;
import com.amazonaws.regions.Regions;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.UUID;

//import android.support.v7.app.AppCompatActivity;
//import androidx.appcompat.app.AppCompatActivity;
public class fishtank extends AppCompatActivity {


    Handler mHandler = new Handler();





    //from pubsub
    static final String LOG_TAG = fishtank.class.getCanonicalName();
    // --- Constants to modify per your configuration ---
    // Customer specific IoT endpoint
    // AWS Iot CLI describe-endpoint call returns: XXXXXXXXXX.iot.<region>.amazonaws.com,
    private static final String CUSTOMER_SPECIFIC_ENDPOINT = "a2r53qtneah6m2-ats.iot.us-west-2.amazonaws.com";

    // Cognito pool ID. For this app, pool needs to be unauthenticated pool with
    // AWS IoT permissions.
    private static final String COGNITO_POOL_ID = "us-west-2:cc7e8d4a-2ae2-41ff-be95-62e03a0f9c9f";

    // Region of AWS IoT
    private static final Regions MY_REGION = Regions.US_WEST_2;


    //wifi
    broadcastReceiver broadcastReceiver = new broadcastReceiver();
    private android.widget.Switch pump;
    private TextView tempvaluetxt,pHvaluetxt, tdsvaluetxt, ecvaluetxt,waterlvlvaluetxt,tvStatus;
    private Button connectbtn,backbtn,disconnectbtn,refresh,feeder;
    private Spinner dropdownmenu;
    String getstatepump,getstatefeeder;


    AWSIotMqttManager mqttManager;
    String clientId;

    CognitoCachingCredentialsProvider credentialsProvider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fishtank);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);


        tempvaluetxt = (TextView) findViewById(R.id.tempvaluetxt);
        pHvaluetxt = (TextView) findViewById(R.id.pHvaluetxt);
        tdsvaluetxt = (TextView) findViewById(R.id.tdsvaluetxt);
        ecvaluetxt = (TextView) findViewById(R.id.ecvaluetxt);
        waterlvlvaluetxt = (TextView) findViewById(R.id.waterlvlvaluetxt);
        tvStatus = (TextView) findViewById(R.id.tvStatus);
        backbtn = (Button) findViewById(R.id.backbtn);
        pump = (android.widget.Switch) findViewById(R.id.pump);
        pump.setOnClickListener(changepump);
        feeder = (Button) findViewById(R.id.feeder);
        feeder.setOnClickListener(changefeeder);
        refresh = (Button) findViewById(R.id.refresh);
        refresh.setOnClickListener(refreshClick);
        connectbtn = (Button) findViewById(R.id.connectbtn);
        backbtn.setOnClickListener(backClick);
        connectbtn.setOnClickListener(connectClick);
        connectbtn.setEnabled(false);
        disconnectbtn = (Button) findViewById(R.id.disconnectbtn);
        disconnectbtn.setOnClickListener(disconnectClick);

        // MQTT client IDs are required to be unique per AWS IoT account.
        // This UUID is "practically unique" but does not _guarantee_
        // uniqueness.
        clientId = UUID.randomUUID().toString();
        // Initialize the AWS Cognito credentials provider
        credentialsProvider = new CognitoCachingCredentialsProvider(
                getApplicationContext(), // context
                COGNITO_POOL_ID, // Identity Pool ID
                MY_REGION // Region
        );
        // MQTT Client
        mqttManager = new AWSIotMqttManager(clientId, CUSTOMER_SPECIFIC_ENDPOINT);
        // The following block uses a Cognito credentials provider for authentication with AWS IoT.

                /*runOnUiThread(new Runnable() {
                    @Override
                    public void run() {*/
                        connectbtn.setEnabled(true);
        //startRepeatingTask();




    }// end of Oncreate

    public void getSpeechInput(View view) {

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, 10);
        } else {
            Toast.makeText(this, "Your Device Don't Support Speech Input", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 10:
                if (resultCode == RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    if(result.get(0).equals("pump on") || result.get(0).equals("pumpkin")){

                        final String topic = "$aws/things/farm1/shadow/update";
                            final String msg = "{\n" +
                                    "\"state\": {\n" +
                                    "\"desired\": {\n" +
                                    "\"iswaterpumpOn\": \"true\"\n" +
                                    "}\n" +
                                    "}\n" +
                                    "}";
                            try {
                                mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                            } catch (Exception e) {
                                Log.e(LOG_TAG, "Publish error.", e);
                            }

                        Toast.makeText(this, "Pump turn on", Toast.LENGTH_SHORT).show();
                    }
                    else if(result.get(0).equals("pump off") || result.get(0).equals("pump of")){
                        final String topic = "$aws/things/farm1/shadow/update";
                        final String msg = "{\n" +
                                "\"state\": {\n" +
                                "\"desired\": {\n" +
                                "\"iswaterpumpOn\": \"false\"\n" +
                                "}\n" +
                                "}\n" +
                                "}";
                        try {
                            mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                        } catch (Exception e) {
                            Log.e(LOG_TAG, "Publish error.", e);
                        }

                        Toast.makeText(this, "Pump turn off", Toast.LENGTH_SHORT).show();
                    }
                    else if(result.get(0).equals("Feeder on") || result.get(0).equals("feeder on")){
                        final String topic = "$aws/things/farm1/shadow/update";
                        final String msg = "{\n" +
                                "\"state\": {\n" +
                                "\"desired\": {\n" +
                                "\"Feeder\": \"true\"\n" +
                                "}\n" +
                                "}\n" +
                                "}";
                        try {
                            mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                        } catch (Exception e) {
                            Log.e(LOG_TAG, "Publish error.", e);
                        }

                        Toast.makeText(this, "Feeder turn on", Toast.LENGTH_SHORT).show();
                    }

                }
                break;
        }
    }

    Runnable mHandlerTask = new Runnable()
    {
        @Override
        public void run() {

            mHandler.postDelayed(mHandlerTask, 1000);
        }
    };

    View.OnClickListener backClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(fishtank.this, dashboard.class);
            startActivity(intent);
            //stopRepeatingTask();

        }
    };


    View.OnClickListener connectClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            Log.d(LOG_TAG, "clientId = " + clientId);

            try {
                mqttManager.connect(credentialsProvider, new AWSIotMqttClientStatusCallback() {
                    @Override
                    public void onStatusChanged(final AWSIotMqttClientStatus status,
                                                final Throwable throwable) {
                        Log.d(LOG_TAG, "Status = " + String.valueOf(status));

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (status == AWSIotMqttClientStatus.Connecting) {
                                    tvStatus.setText("Connecting...");
                                    tvStatus.setTextColor(Color.parseColor("#4CAF50"));

                                } else if (status == AWSIotMqttClientStatus.Connected) {
                                    tvStatus.setText("Connected");
                                    tvStatus.setTextColor(Color.parseColor("#4CAF50"));
                                    final String topictemp = "watertemp";
                                    final String topicph = "phlevel";
                                    final String topictds = "tds";
                                    final String topicec = "ec";
                                    final String topicwaterlvl = "waterlevel";

                                    Log.d(LOG_TAG, "topic = " + topictemp);
                                    Log.d(LOG_TAG, "topic = " + topicph);
                                    Log.d(LOG_TAG, "topic = " + topictds);
                                    Log.d(LOG_TAG, "topic = " + topicec);
                                    Log.d(LOG_TAG, "topic = " + topicwaterlvl);

                                    try {
                                        mqttManager.subscribeToTopic(topictemp, AWSIotMqttQos.QOS0,
                                                new AWSIotMqttNewMessageCallback() {
                                                    @Override
                                                    public void onMessageArrived(final String topictemp, final byte[] data) {
                                                        runOnUiThread(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                try {
                                                                    String message = new String(data, "UTF-8");
                                                                    Log.d(LOG_TAG, "Message arrived:");
                                                                    Log.d(LOG_TAG, "   Topic: " + topictemp);
                                                                    Log.d(LOG_TAG, " Message: " + message);

                                                                    //message = message.replaceAll("[^0-9]", "");
                                                                    message = message.replaceAll("[^\\d.]", "");
                                                                    tempvaluetxt.setText(message + " °C");

                                                                } catch (UnsupportedEncodingException e) {
                                                                    Log.e(LOG_TAG, "Message encoding error.", e);
                                                                }
                                                            }
                                                        });
                                                    }
                                                });

                                    } catch (AmazonServiceException e){
                                        Log.e(LOG_TAG, "AmazonServiceException", e);
                                    }catch (AmazonClientException e){
                                        Log.e(LOG_TAG, "AmazonClientException", e);
                                    }
                                    catch (NullPointerException e){
                                        Log.e(LOG_TAG, "NullPointerException", e);
                                    }catch (Exception e) {
                                        Log.e(LOG_TAG, "Subscription error.", e);
                                    }

                                    try{
                                        mqttManager.subscribeToTopic(topicph, AWSIotMqttQos.QOS0,
                                                new AWSIotMqttNewMessageCallback() {
                                                    @Override
                                                    public void onMessageArrived(final String topicph, final byte[] data) {
                                                        runOnUiThread(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                try {
                                                                    String message = new String(data, "UTF-8");
                                                                    Log.d(LOG_TAG, "Message arrived:");
                                                                    Log.d(LOG_TAG, "   Topic: " + topicph);
                                                                    Log.d(LOG_TAG, " Message: " + message);
                                                                    message = message.replaceAll("[^\\d.]", "");
                                                                    pHvaluetxt.setText(message + " pH");

                                                                } catch (UnsupportedEncodingException e) {
                                                                    Log.e(LOG_TAG, "Message encoding error.", e);
                                                                }
                                                            }
                                                        });
                                                    }
                                                });
                                    }catch (AmazonServiceException e){
                                        Log.e(LOG_TAG, "AmazonServiceException", e);
                                    }catch (AmazonClientException e){
                                        Log.e(LOG_TAG, "AmazonClientException", e);
                                    }
                                    catch (NullPointerException e){
                                        Log.e(LOG_TAG, "NullPointerException", e);
                                    }catch (Exception e) {
                                        Log.e(LOG_TAG, "Subscription error.", e);
                                    }

                                    try{
                                        mqttManager.subscribeToTopic(topictds, AWSIotMqttQos.QOS0,
                                                new AWSIotMqttNewMessageCallback() {
                                                    @Override
                                                    public void onMessageArrived(final String topictds, final byte[] data) {
                                                        runOnUiThread(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                try {
                                                                    String message = new String(data, "UTF-8");
                                                                    Log.d(LOG_TAG, "Message arrived:");
                                                                    Log.d(LOG_TAG, "   Topic: " + topictds);
                                                                    Log.d(LOG_TAG, " Message: " + message);
                                                                    message = message.replaceAll("[^\\d.]", "");
                                                                    tdsvaluetxt.setText(message + " ppm");




                                                                } catch (UnsupportedEncodingException e) {
                                                                    Log.e(LOG_TAG, "Message encoding error.", e);
                                                                }
                                                            }
                                                        });
                                                    }
                                                });
                                    }catch (AmazonServiceException e){
                                        Log.e(LOG_TAG, "AmazonServiceException", e);
                                    }catch (AmazonClientException e){
                                        Log.e(LOG_TAG, "AmazonClientException", e);
                                    }
                                    catch (NullPointerException e){
                                        Log.e(LOG_TAG, "NullPointerException", e);
                                    }catch (Exception e) {
                                        Log.e(LOG_TAG, "Subscription error.", e);
                                    }
                                    try{
                                        mqttManager.subscribeToTopic(topicec, AWSIotMqttQos.QOS0,
                                                new AWSIotMqttNewMessageCallback() {
                                                    @Override
                                                    public void onMessageArrived(final String topicec, final byte[] data) {
                                                        runOnUiThread(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                try {
                                                                    String message = new String(data, "UTF-8");
                                                                    Log.d(LOG_TAG, "Message arrived:");
                                                                    Log.d(LOG_TAG, "   Topic: " + topicec);
                                                                    Log.d(LOG_TAG, " Message: " + message);
                                                                    message = message.replaceAll("[^\\d.]", "");
                                                                    ecvaluetxt.setText(message + " µS");

                                                                } catch (UnsupportedEncodingException e) {
                                                                    Log.e(LOG_TAG, "Message encoding error.", e);
                                                                }
                                                            }
                                                        });
                                                    }
                                                });
                                    }catch (AmazonServiceException e){
                                        Log.e(LOG_TAG, "AmazonServiceException", e);
                                    }catch (AmazonClientException e){
                                        Log.e(LOG_TAG, "AmazonClientException", e);
                                    }
                                    catch (NullPointerException e){
                                        Log.e(LOG_TAG, "NullPointerException", e);
                                    }catch (Exception e) {
                                        Log.e(LOG_TAG, "Subscription error.", e);
                                    }

                                    try{
                                        mqttManager.subscribeToTopic(topicwaterlvl, AWSIotMqttQos.QOS0,
                                                new AWSIotMqttNewMessageCallback() {
                                                    @Override
                                                    public void onMessageArrived(final String topicwaterlvl, final byte[] data) {
                                                        runOnUiThread(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                try {
                                                                    String message = new String(data, "UTF-8");
                                                                    Log.d(LOG_TAG, "Message arrived:");
                                                                    Log.d(LOG_TAG, "   Topic: " + topicwaterlvl);
                                                                    Log.d(LOG_TAG, " Message: " + message);
                                                                    message = message.replaceAll("[^\\d.]", "");
                                                                    waterlvlvaluetxt.setText(message + " %");

                                                                } catch (UnsupportedEncodingException e) {
                                                                    Log.e(LOG_TAG, "Message encoding error.", e);
                                                                }
                                                            }
                                                        });
                                                    }
                                                });
                                    }catch (AmazonServiceException e){
                                        Log.e(LOG_TAG, "AmazonServiceException", e);
                                    }catch (AmazonClientException e){
                                        Log.e(LOG_TAG, "AmazonClientException", e);
                                    }
                                    catch (NullPointerException e){
                                        Log.e(LOG_TAG, "NullPointerException", e);
                                    }catch (Exception e) {
                                        Log.e(LOG_TAG, "Subscription error.", e);
                                    }



                                } else if (status == AWSIotMqttClientStatus.Reconnecting) {
                                    if (throwable != null) {
                                        Log.e(LOG_TAG, "Connection error.", throwable);
                                    }
                                    tvStatus.setText("Reconnecting");
                                } else if (status == AWSIotMqttClientStatus.ConnectionLost) {
                                    if (throwable != null) {
                                        Log.e(LOG_TAG, "Connection error.", throwable);
                                        throwable.printStackTrace();
                                    }
                                    tvStatus.setText("Disconnected");
                                    tvStatus.setTextColor(Color.parseColor("#F3144E"));

                                } else {
                                    tvStatus.setText("Disconnected");
                                    tvStatus.setTextColor(Color.parseColor("#F3144E"));

                                }
                            }
                        });
                    }
                });
            } catch (final Exception e) {
                Log.e(LOG_TAG, "Connection error.", e);
                tvStatus.setText("Error! " + e.getMessage());
            }

        }
    };
    @Override
    protected void onStart() {
        super.onStart();
        //Check internet connection
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(broadcastReceiver, filter);

    }


    @Override
    protected void onPause() {
        super.onPause();
        //stopRepeatingTask();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(broadcastReceiver);
        //stopRepeatingTask();


    }

    View.OnClickListener disconnectClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            try {
                mqttManager.disconnect();
            } catch (Exception e) {
                Log.e(LOG_TAG, "Disconnect error.", e);
            }

        }
    };

    View.OnClickListener refreshClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            //new fishtank.().execute();
            //new fishtank.getstatepump().execute();

                                            /*new getontimelight1().execute();
            new getofftimelight1().execute();
            new getontimelight2().execute();
            new getofftimelight2().execute();*/
            final String topic = "$aws/things/farm1/shadow/get/accepted";

            Log.d(LOG_TAG, "topic = " + topic);

            try {
                mqttManager.subscribeToTopic(topic, AWSIotMqttQos.QOS0,
                        new AWSIotMqttNewMessageCallback() {
                            @Override
                            public void onMessageArrived(final String topic, final byte[] data) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            String message = new String(data, "UTF-8");

                                            Log.d(LOG_TAG, "Message arrived:");
                                            Log.d(LOG_TAG, "   Topic: " + topic);
                                            Log.d(LOG_TAG, " Message: " + message);
                                            try {
                                                // get JSONObject from JSON file
                                                JSONObject obj = new JSONObject(message);
                                                // fetch JSONObject named employee
                                                JSONObject state = obj.getJSONObject("state");
                                                JSONObject desired = state.getJSONObject("desired");
                                                getstatepump = desired.getString("iswaterpumpOn");


                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }

                                            if (getstatepump.equals("true")) {

                                                pump.setChecked(true);

                                            }
                                            else{

                                                pump.setChecked(false);
                                            }


                                        } catch (UnsupportedEncodingException e) {
                                            Log.e(LOG_TAG, "Message encoding error.", e);
                                        }
                                    }
                                });
                            }
                        });
            } catch (Exception e) {
                Log.e(LOG_TAG, "Subscription error.", e);
            }

            final String topicpub = "$aws/things/farm1/shadow/get";
            final String msg = String.format("");

            try {
                mqttManager.publishString(msg, topicpub, AWSIotMqttQos.QOS0);
            } catch (Exception e) {
                Log.e(LOG_TAG, "Publish error.", e);
            }
        }


    };

    View.OnClickListener changepump = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            final String topic = "$aws/things/farm1/shadow/update";
            if(pump.isChecked()== true){
                final String msg = "{\n" +
                        "\"state\": {\n" +
                        "\"desired\": {\n" +
                        "\"iswaterpumpOn\": \"true\"\n" +
                        "}\n" +
                        "}\n" +
                        "}";
                try {
                    mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                } catch (Exception e) {
                    Log.e(LOG_TAG, "Publish error.", e);
                }
            }
            else{
                final String msg = "{\n" +
                        "\"state\": {\n" +
                        "\"desired\": {\n" +
                        "\"iswaterpumpOn\": \"false\"\n" +
                        "}\n" +
                        "}\n" +
                        "}";
                try {
                    mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                } catch (Exception e) {
                    Log.e(LOG_TAG, "Publish error.", e);
                }
            }
        }
    };
    View.OnClickListener changefeeder = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            final String topic = "$aws/things/farm1/shadow/update";
                final String msg = "{\n" +
                        "\"state\": {\n" +
                        "\"desired\": {\n" +
                        "\"Feederstate\": \"true\"\n" +
                        "}\n" +
                        "}\n" +
                        "}";
                try {
                    mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                } catch (Exception e) {
                    Log.e(LOG_TAG, "Publish error.", e);
                }
            }

    };

    /*private class getstatepump extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(fishtank.this);
            mapperfishtank mapperfishtank = new mapperfishtank();


            if (credentialsProvider != null && mapperfishtank != null) {
                DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                try{
                    mapperfishtank = dynamoDBMapper.load(mapperfishtank.class, getpump);
                    getstatepump = mapperfishtank.getState();
                }catch (AmazonServiceException e){
                    Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (AmazonClientException e){
                    Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            } else {
                return 2;
            }
            return 1;
        }


        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {
                if (getstatepump.equals("Off")) {
                    pump.setChecked(false);
                }
                else if(getstatepump.equals("On")){
                    pump.setChecked(true);
                }
            }

        }


    }*/

}


