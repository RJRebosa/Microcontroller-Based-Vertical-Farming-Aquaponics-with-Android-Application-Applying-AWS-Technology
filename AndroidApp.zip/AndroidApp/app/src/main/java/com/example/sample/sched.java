package com.example.sample;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttClientStatusCallback;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttManager;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttNewMessageCallback;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttQos;
import com.amazonaws.regions.Regions;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

//import androidx.appcompat.app.AppCompatActivity;
public class sched extends AppCompatActivity{
    //from pubsub
    static final String LOG_TAG = farm2.class.getCanonicalName();
    // --- Constants to modify per your configuration ---
    // Customer specific IoT endpoint
    // AWS Iot CLI describe-endpoint call returns: XXXXXXXXXX.iot.<region>.amazonaws.com,
    private static final String CUSTOMER_SPECIFIC_ENDPOINT = "a2r53qtneah6m2-ats.iot.us-west-2.amazonaws.com";

    // Cognito pool ID. For this app, pool needs to be unauthenticated pool with
    // AWS IoT permissions.
    private static final String COGNITO_POOL_ID = "us-west-2:cc7e8d4a-2ae2-41ff-be95-62e03a0f9c9f";

    // Region of AWS IoT
    private static final Regions MY_REGION = Regions.US_WEST_2;
    // Region of AWS IoT
    //get value of iot shadow fishtank
    String getstateontimepump,getstateofftimepump,getstatefirstfeed,getstatesecondfeed,getstateamount;
    //get value of iot shadow farm1
    String getstateonlight1,getstateofflight1,getstateonlight2,getstateofflight2;
    String getpump = "water pump";
    String getfishfeeder = "fish feeder";
    String light1 = "Light1";
    String light2 = "Light2";
    String light3 = "Light3";
    String light4 = "Light4";
    String getontimepump,getfirsttimefeed, getsecondtimefeed, getamount,getofftimepump,getontimelight1,getontimelight2,getofftimelight1,getofftimelight2,getontimelight3,getontimelight4,getofftimelight3,getofftimelight4;
    Integer hour, minutes;
    //public String hour, min;
    public String time,amPm,time1,amountfeed,aTime;
    Calendar calendar;
    SimpleDateFormat simpleDateFormat;
    Button backbtn,refresh,refresh1,refresh2,setamountfeedbtn;
    TextView pumpontimevalue,pumpofftimevalue,firstfeedtimevalue,secondfeedtimevalue,light1ontimevalue,light1offtimevalue,light2ontimevalue,light2offtimevalue,light3ontimevalue,light3offtimevalue,light4ontimevalue,light4offtimevalue;
    EditText amountoffeedvalue;
    //wifi
    broadcastReceiver broadcastReceiver = new broadcastReceiver();

    AWSIotMqttManager mqttManager;
    String clientId;
    CognitoCachingCredentialsProvider credentialsProvider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sched);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        backbtn = (Button) findViewById(R.id.backbtn);
        backbtn.setOnClickListener(backClick);
        refresh = (Button) findViewById(R.id.refresh);
        refresh.setOnClickListener(refreshClick);
        refresh1 = (Button) findViewById(R.id.refresh1);
        refresh1.setOnClickListener(refresh1Click);
        refresh2 = (Button) findViewById(R.id.refresh2);
        refresh2.setOnClickListener(refresh2Click);
        pumpontimevalue = (TextView) findViewById(R.id.onpumpschedvaluetxt);
        pumpontimevalue.setOnClickListener(setpumpontime);
        pumpofftimevalue = (TextView) findViewById(R.id.offpumpschedvaluetxt);
        pumpofftimevalue.setOnClickListener(setpumpofftime);
        firstfeedtimevalue = (TextView) findViewById(R.id.firstfeedschedvaluetxt);
        firstfeedtimevalue.setOnClickListener(setfirstfeedtime);
        secondfeedtimevalue = (TextView) findViewById(R.id.secondfeedschedvaluetxt);
        secondfeedtimevalue.setOnClickListener(setsecondfeedtime);
        amountoffeedvalue = (EditText) findViewById(R.id.amountfeedschedvaluetxt);
        setamountfeedbtn = (Button) findViewById(R.id.setamountbtn);
        setamountfeedbtn.setOnClickListener(setamountoffeed);
        light1ontimevalue = (TextView) findViewById(R.id.onlight1schedvaluetxt);
        light1ontimevalue.setOnClickListener(setlight1ontime);
        light1ontimevalue.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        light1offtimevalue = (TextView) findViewById(R.id.offlight1schedvaluetxt);
        light1offtimevalue.setOnClickListener(setlight1offtime);
        light2ontimevalue = (TextView) findViewById(R.id.onlight2schedvaluetxt);
        light2ontimevalue.setOnClickListener(setlight2ontime);
        light2offtimevalue = (TextView) findViewById(R.id.offlight2schedvaluetxt);
        light2offtimevalue.setOnClickListener(setlight2offtime);
        light3ontimevalue = (TextView) findViewById(R.id.onlight3schedvaluetxt);
        light3ontimevalue.setOnClickListener(setlight3ontime);
        light3offtimevalue = (TextView) findViewById(R.id.offlight3schedvaluetxt);
        light3offtimevalue.setOnClickListener(setlight3offtime);
        light4ontimevalue = (TextView) findViewById(R.id.onlight4schedvaluetxt);
        light4ontimevalue.setOnClickListener(setlight4ontime);
        light4offtimevalue = (TextView) findViewById(R.id.offlight4schedvaluetxt);
        light4offtimevalue.setOnClickListener(setlight4offtime);
        calendar = Calendar.getInstance();
        //simpleDateFormat = new SimpleDateFormat("H:mm");
// MQTT client IDs are required to be unique per AWS IoT account.
        // This UUID is "practically unique" but does not _guarantee_
        // uniqueness.
        clientId = UUID.randomUUID().toString();
        // Initialize the AWS Cognito credentials provider
        credentialsProvider = new CognitoCachingCredentialsProvider(
                getApplicationContext(), // context
                COGNITO_POOL_ID, // Identity Pool ID
                MY_REGION // Region
        );
        // MQTT Client
        mqttManager = new AWSIotMqttManager(clientId, CUSTOMER_SPECIFIC_ENDPOINT);

    }
    private class getontimepump extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {

            mapperfishtank mapperfishtank = new mapperfishtank();
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(sched.this);
            if (credentialsProvider != null && mapperfishtank != null) {
                try{
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    mapperfishtank = dynamoDBMapper.load(mapperfishtank.class, getpump);
                    getontimepump = mapperfishtank.getOnTime();

                }catch (AmazonServiceException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (AmazonClientException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
            else {
                return 2;
            }
            return 1;
        }
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {

                pumpontimevalue.setText(getontimepump);
            }
        }
    }
    private class getofftimepump extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {

            mapperfishtank mapperfishtank = new mapperfishtank();
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(sched.this);
            if (credentialsProvider != null && mapperfishtank != null) {
                try{
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    mapperfishtank = dynamoDBMapper.load(mapperfishtank.class, getpump);
                    getofftimepump = mapperfishtank.getOfftime();

                }catch (AmazonServiceException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (AmazonClientException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
            else {
                return 2;
            }
            return 1;
        }
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {
                pumpofftimevalue.setText(getofftimepump);
            }
        }
    }
    private class getfirsttimefishfeed extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {

            mapperfishtank mapperfishtank = new mapperfishtank();
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(sched.this);
            if (credentialsProvider != null && mapperfishtank != null) {
                try{
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    mapperfishtank = dynamoDBMapper.load(mapperfishtank.class, getfishfeeder);
                    getfirsttimefeed = mapperfishtank.getFirsttime();

                }catch (AmazonServiceException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (AmazonClientException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
            else {
                return 2;
            }
            return 1;
        }
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {

                firstfeedtimevalue.setText(getfirsttimefeed);
            }
        }
    }
    private class getsecondtimefishfeed extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {

            mapperfishtank mapperfishtank = new mapperfishtank();
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(sched.this);
            if (credentialsProvider != null && mapperfishtank != null) {
                try{
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    mapperfishtank = dynamoDBMapper.load(mapperfishtank.class, getfishfeeder);
                    getsecondtimefeed = mapperfishtank.getSecondtime();

                }catch (AmazonServiceException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (AmazonClientException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
            else {
                return 2;
            }
            return 1;
        }
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {

                secondfeedtimevalue.setText(getsecondtimefeed);
            }
        }
    }
    private class getamountfishfeed extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {

            mapperfishtank mapperfishtank = new mapperfishtank();
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(sched.this);
            if (credentialsProvider != null && mapperfishtank != null) {
                try{
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    mapperfishtank = dynamoDBMapper.load(mapperfishtank.class, getfishfeeder);
                    getamount = mapperfishtank.getAmount();

                }catch (AmazonServiceException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (AmazonClientException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
            else {
                return 2;
            }
            return 1;
        }
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {

                amountoffeedvalue.setText(getamount);
            }
        }
    }

   /* private class getontimelight1 extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {

            mapperfarm1state mapperfarm1state = new mapperfarm1state();
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(sched.this);
            if (credentialsProvider != null && mapperfarm1state != null) {
                try{
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    mapperfarm1state = dynamoDBMapper.load(mapperfarm1state.class, light1);
                    getontimelight1 = mapperfarm1state.getOntime();

                }catch (AmazonServiceException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (AmazonClientException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
            else {
                return 2;
            }
            return 1;
        }
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {
                light1ontimevalue.setText(getontimelight1);
            }
        }
    }*/
  /*  private class getofftimelight1 extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {

            mapperfarm1state mapperfarm1state = new mapperfarm1state();
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(sched.this);
            if (credentialsProvider != null && mapperfarm1state != null) {
                try{
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    mapperfarm1state = dynamoDBMapper.load(mapperfarm1state.class, light1);
                    getofftimelight1 = mapperfarm1state.getOfftime();

                }catch (AmazonServiceException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (AmazonClientException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
            else {
                return 2;
            }
            return 1;
        }
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {

                light1offtimevalue.setText(getofftimelight1);
            }
        }
    }*/
   /* private class getontimelight2 extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {

            mapperfarm1state mapperfarm1state = new mapperfarm1state();
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(sched.this);
            if (credentialsProvider != null && mapperfarm1state != null) {
                try{
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    mapperfarm1state = dynamoDBMapper.load(mapperfarm1state.class, light2);
                    getontimelight2 = mapperfarm1state.getOntime();

                }catch (AmazonServiceException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (AmazonClientException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
            else {
                return 2;
            }
            return 1;
        }
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {

                light2ontimevalue.setText(getontimelight2);
            }
        }
    }
    private class getofftimelight2 extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {

            mapperfarm1state mapperfarm1state = new mapperfarm1state();
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(sched.this);
            if (credentialsProvider != null && mapperfarm1state != null) {
                try{
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    mapperfarm1state = dynamoDBMapper.load(mapperfarm1state.class, light2);
                    getofftimelight2 = mapperfarm1state.getOfftime();

                }catch (AmazonServiceException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (AmazonClientException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
            else {
                return 2;
            }
            return 1;
        }
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {

                light2offtimevalue.setText(getofftimelight2);
            }
        }
    }
    private class getontimelight3 extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {

            mapperfarm1state mapperfarm1state = new mapperfarm1state();
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(sched.this);
            if (credentialsProvider != null && mapperfarm1state != null) {
                try{
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    mapperfarm1state = dynamoDBMapper.load(mapperfarm1state.class, light3);
                    getontimelight3 = mapperfarm1state.getOntime();

                }catch (AmazonServiceException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (AmazonClientException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
            else {
                return 2;
            }
            return 1;
        }
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {

                light3ontimevalue.setText(getontimelight3);
            }
        }
    }
    private class getofftimelight3 extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {

            mapperfarm1state mapperfarm1state = new mapperfarm1state();
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(sched.this);
            if (credentialsProvider != null && mapperfarm1state != null) {
                try{
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    mapperfarm1state = dynamoDBMapper.load(mapperfarm1state.class, light3);
                    getofftimelight3 = mapperfarm1state.getOfftime();

                }catch (AmazonServiceException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (AmazonClientException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
            else {
                return 2;
            }
            return 1;
        }
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {

                light3offtimevalue.setText(getofftimelight3);
            }
        }
    }
    private class getontimelight4 extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {

            mapperfarm1state mapperfarm1state = new mapperfarm1state();
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(sched.this);
            if (credentialsProvider != null && mapperfarm1state != null) {
                try{
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    mapperfarm1state = dynamoDBMapper.load(mapperfarm1state.class, light4);
                    getontimelight4 = mapperfarm1state.getOntime();

                }catch (AmazonServiceException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (AmazonClientException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
            else {
                return 2;
            }
            return 1;
        }
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {

                light4ontimevalue.setText(getontimelight4);
            }
        }
    }
    private class getofftimelight4 extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {

            mapperfarm1state mapperfarm1state = new mapperfarm1state();
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(sched.this);
            if (credentialsProvider != null && mapperfarm1state != null) {
                try{
                    DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                    mapperfarm1state = dynamoDBMapper.load(mapperfarm1state.class, light4);
                    getofftimelight4 = mapperfarm1state.getOfftime();

                }catch (AmazonServiceException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                catch (AmazonClientException e){
                    //Toast.makeText(fishtank.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
            else {
                return 2;
            }
            return 1;
        }
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

            if (integer == 1) {

                light4offtimevalue.setText(getofftimelight4);
            }
        }
    }*/







    View.OnClickListener backClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(sched.this, dashboard.class);
            startActivity(intent);
            //stopRepeatingTask();

        }
    };
    View.OnClickListener setpumpontime = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            calendar = Calendar.getInstance();
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minutes = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(sched.this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                    hour = hourOfDay;
                    minutes = minutes;
                    String timeSet = "";
                    if (hour > 12) {
                        hour -= 12;
                        timeSet = "PM";
                    } else if (hour == 0) {
                        hour += 12;
                        timeSet = "AM";
                    } else if (hour == 12){
                        timeSet = "PM";
                    }else{
                        timeSet = "AM";
                    }

                    String min = "";
                    if (minutes < 10)
                        min = "0" + minutes ;
                    else
                        min = String.valueOf(minutes);

                    // Append in a StringBuilder
                    aTime = new StringBuilder().append(hour).append(':')
                            .append(min ).append(" ").append(timeSet).toString();
                        pumpontimevalue.setText(aTime);
                        final String topic = "$aws/things/farm1/shadow/update";
                        final String msg = String.format("{ \"state\": { \"desired\" : { \"Ontime\":\"%s\"} } }",aTime);

                        try {
                            mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                        } catch (Exception e) {
                            Log.e(LOG_TAG, "Publish error.", e);
                        }

                }
            }, hour, minutes, false);

            timePickerDialog.show();
        }
    };
    View.OnClickListener setpumpofftime = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            calendar = Calendar.getInstance();
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minutes = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(sched.this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                    hour = hourOfDay;
                    minutes = minutes;
                    String timeSet = "";
                    if (hour > 12) {
                        hour -= 12;
                        timeSet = "PM";
                    } else if (hour == 0) {
                        hour += 12;
                        timeSet = "AM";
                    } else if (hour == 12){
                        timeSet = "PM";
                    }else{
                        timeSet = "AM";
                    }

                    String min = "";
                    if (minutes < 10)
                        min = "0" + minutes ;
                    else
                        min = String.valueOf(minutes);

                    // Append in a StringBuilder
                    aTime = new StringBuilder().append(hour).append(':')
                            .append(min ).append(" ").append(timeSet).toString();
                        pumpofftimevalue.setText(aTime);
                        final String topic = "$aws/things/farm1/shadow/update";
                        final String msg = String.format("{ \"state\": { \"desired\" : { \"Offtime\":\"%s\"} } }",aTime);

                        try {
                            mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                        } catch (Exception e) {
                            Log.e(LOG_TAG, "Publish error.", e);
                        }

                }
            }, hour, minutes, false);

            timePickerDialog.show();
        }

    };

    View.OnClickListener setfirstfeedtime = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            calendar = Calendar.getInstance();
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minutes = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(sched.this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                    hour = hourOfDay;
                    minutes = minutes;
                    String timeSet = "";
                    if (hour > 12) {
                        hour -= 12;
                        timeSet = "PM";
                    } else if (hour == 0) {
                        hour += 12;
                        timeSet = "AM";
                    } else if (hour == 12){
                        timeSet = "PM";
                    }else{
                        timeSet = "AM";
                    }

                    String min = "";
                    if (minutes < 10)
                        min = "0" + minutes ;
                    else
                        min = String.valueOf(minutes);

                    // Append in a StringBuilder
                    aTime = new StringBuilder().append(hour).append(':')
                            .append(min ).append(" ").append(timeSet).toString();

                        firstfeedtimevalue.setText(aTime);
                        final String topic = "$aws/things/farm1/shadow/update";
                        final String msg = String.format("{ \"state\": { \"desired\" : { \"Time1\":\"%s\"} } }",aTime);

                        try {
                            mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                        } catch (Exception e) {
                            Log.e(LOG_TAG, "Publish error.", e);
                        }

                }
            }, hour, minutes, false);

            timePickerDialog.show();

        }
    };
    View.OnClickListener setsecondfeedtime = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            calendar = Calendar.getInstance();
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minutes = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(sched.this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                    hour = hourOfDay;
                    minutes = minutes;
                    String timeSet = "";
                    if (hour > 12) {
                        hour -= 12;
                        timeSet = "PM";
                    } else if (hour == 0) {
                        hour += 12;
                        timeSet = "AM";
                    } else if (hour == 12){
                        timeSet = "PM";
                    }else{
                        timeSet = "AM";
                    }

                    String min = "";
                    if (minutes < 10)
                        min = "0" + minutes ;
                    else
                        min = String.valueOf(minutes);

                    // Append in a StringBuilder
                     aTime = new StringBuilder().append(hour).append(':')
                            .append(min ).append(" ").append(timeSet).toString();
                    secondfeedtimevalue.setText(aTime);
                    final String topic = "$aws/things/farm1/shadow/update";
                    final String msg = String.format("{ \"state\": { \"desired\" : { \"Time2\":\"%s\"} } }",aTime);

                    try {
                        mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                    } catch (Exception e) {
                        Log.e(LOG_TAG, "Publish error.", e);
                    }
                }
            }, hour, minutes, false);

            timePickerDialog.show();

        }
    };
    View.OnClickListener setamountoffeed = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

                    amountfeed = amountoffeedvalue.getText().toString();

                        if(amountfeed.equals(null) || amountfeed.equals("") || amountfeed.equals("0") ){
                            Toast.makeText(sched.this, "Incorrect input!", Toast.LENGTH_SHORT).show();

                        }
                        else {

                            final String topic = "$aws/things/farm1/shadow/update";
                            final String msg = String.format("{ \"state\": { \"desired\" : { \"Amount\":\"%s\"} } }",amountfeed);
                            Toast.makeText(sched.this, "Updated!", Toast.LENGTH_SHORT).show();

                            try {
                                mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                            } catch (Exception e) {
                                Log.e(LOG_TAG, "Publish error.", e);
                            }
                        }

        }
   };

    View.OnClickListener setlight1ontime = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            calendar = Calendar.getInstance();
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minutes = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(sched.this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                    //if (hourOfDay >= 12) {
                      //  amPm = "PM";
                   // } else {
                       // amPm = "AM";
                    //}
                   // time = hourOfDay + ":" + minutes;
                    //final SimpleDateFormat sdf = new SimpleDateFormat("H:mm");
                    //final Date dateObj;
                    //try {
                       // dateObj = sdf.parse(time);
                       // time1 = (new SimpleDateFormat("K:mm").format(dateObj));
                       // time2 = time1 + " " + amPm;
                    hour = hourOfDay;
                    minutes = minutes;
                    String timeSet = "";
                    if (hour > 12) {
                        hour -= 12;
                        timeSet = "PM";
                    } else if (hour == 0) {
                        hour += 12;
                        timeSet = "AM";
                    } else if (hour == 12){
                        timeSet = "PM";
                    }else{
                        timeSet = "AM";
                    }

                    String min = "";
                    if (minutes < 10)
                        min = "0" + minutes ;
                    else
                        min = String.valueOf(minutes);

                    // Append in a StringBuilder
                    aTime = new StringBuilder().append(hour).append(':')
                            .append(min ).append(" ").append(timeSet).toString();
                        light1ontimevalue.setText(aTime);
                        final String topic = "$aws/things/farm1/shadow/update";
                        final String msg = String.format("{ \"state\": { \"desired\" : { \"Ontimelight1\":\"%s\"} } }",aTime);

                        try {
                            mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                        } catch (Exception e) {
                            Log.e(LOG_TAG, "Publish error.", e);
                        }
                    //} catch (ParseException e) {
                       // e.printStackTrace();
                    //}
                }
            }, hour, minutes, false);

            timePickerDialog.show();

        }
    };
    View.OnClickListener setlight1offtime = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            calendar = Calendar.getInstance();
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minutes = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(sched.this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                    hour = hourOfDay;
                    minutes = minutes;
                    String timeSet = "";
                    if (hour > 12) {
                        hour -= 12;
                        timeSet = "PM";
                    } else if (hour == 0) {
                        hour += 12;
                        timeSet = "AM";
                    } else if (hour == 12){
                        timeSet = "PM";
                    }else{
                        timeSet = "AM";
                    }

                    String min = "";
                    if (minutes < 10)
                        min = "0" + minutes ;
                    else
                        min = String.valueOf(minutes);

                    // Append in a StringBuilder
                    aTime = new StringBuilder().append(hour).append(':')
                            .append(min ).append(" ").append(timeSet).toString();
                        light1offtimevalue.setText(aTime);
                        final String topic = "$aws/things/farm1/shadow/update";
                        final String msg = String.format("{ \"state\": { \"desired\" : { \"Offtimelight1\":\"%s\"} } }", aTime);

                        try {
                            mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                        } catch (Exception e) {
                            Log.e(LOG_TAG, "Publish error.", e);
                        }
                }
            }, hour, minutes, false);

            timePickerDialog.show();
        }
        };
    View.OnClickListener setlight2ontime = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            calendar = Calendar.getInstance();
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minutes = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(sched.this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                    hour = hourOfDay;
                    minutes = minutes;
                    String timeSet = "";
                    if (hour > 12) {
                        hour -= 12;
                        timeSet = "PM";
                    } else if (hour == 0) {
                        hour += 12;
                        timeSet = "AM";
                    } else if (hour == 12){
                        timeSet = "PM";
                    }else{
                        timeSet = "AM";
                    }

                    String min = "";
                    if (minutes < 10)
                        min = "0" + minutes ;
                    else
                        min = String.valueOf(minutes);

                    // Append in a StringBuilder
                    aTime = new StringBuilder().append(hour).append(':')
                            .append(min ).append(" ").append(timeSet).toString();
                        light2ontimevalue.setText(aTime);
                        final String topic = "$aws/things/farm1/shadow/update";
                        final String msg = String.format("{ \"state\": { \"desired\" : { \"Ontimelight2\":\"%s\"} } }",aTime);

                        try {
                            mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                        } catch (Exception e) {
                            Log.e(LOG_TAG, "Publish error.", e);
                        }
                }
            }, hour, minutes, false);

            timePickerDialog.show();

        }
    };
    View.OnClickListener setlight2offtime = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            calendar = Calendar.getInstance();
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minutes = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(sched.this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                    hour = hourOfDay;
                    minutes = minutes;
                    String timeSet = "";
                    if (hour > 12) {
                        hour -= 12;
                        timeSet = "PM";
                    } else if (hour == 0) {
                        hour += 12;
                        timeSet = "AM";
                    } else if (hour == 12){
                        timeSet = "PM";
                    }else{
                        timeSet = "AM";
                    }

                    String min = "";
                    if (minutes < 10)
                        min = "0" + minutes ;
                    else
                        min = String.valueOf(minutes);

                    // Append in a StringBuilder
                    aTime = new StringBuilder().append(hour).append(':')
                            .append(min ).append(" ").append(timeSet).toString();
                        light2offtimevalue.setText(aTime);
                        final String topic = "$aws/things/farm1/shadow/update";
                        final String msg = String.format("{ \"state\": { \"desired\" : { \"Offtimelight2\":\"%s\"} } }",aTime);

                        try {
                            mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                        } catch (Exception e) {
                            Log.e(LOG_TAG, "Publish error.", e);
                        }
                }
            }, hour, minutes, false);

            timePickerDialog.show();

        }
    };
    View.OnClickListener setlight3ontime = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            calendar = Calendar.getInstance();
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minutes = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(sched.this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                    hour = hourOfDay;
                    minutes = minutes;
                    String timeSet = "";
                    if (hour > 12) {
                        hour -= 12;
                        timeSet = "PM";
                    } else if (hour == 0) {
                        hour += 12;
                        timeSet = "AM";
                    } else if (hour == 12){
                        timeSet = "PM";
                    }else{
                        timeSet = "AM";
                    }

                    String min = "";
                    if (minutes < 10)
                        min = "0" + minutes ;
                    else
                        min = String.valueOf(minutes);

                    // Append in a StringBuilder
                    aTime = new StringBuilder().append(hour).append(':')
                            .append(min ).append(" ").append(timeSet).toString();
                        light3ontimevalue.setText(aTime);
                }
            }, hour, minutes, false);

            timePickerDialog.show();
        }
    };
    View.OnClickListener setlight3offtime = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            calendar = Calendar.getInstance();
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minutes = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(sched.this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                    if (hourOfDay >= 12) {
                        amPm = "PM";
                    } else {
                        amPm = "AM";
                    }
                    time = hourOfDay + ":" + minutes;
                    final SimpleDateFormat sdf = new SimpleDateFormat("H:mm");
                    final Date dateObj;
                    try {
                        dateObj = sdf.parse(time);
                        time1 = (new SimpleDateFormat("K:mm").format(dateObj));
                        light3offtimevalue.setText(aTime);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }
            }, hour, minutes, false);

            timePickerDialog.show();

        }
    };
    View.OnClickListener setlight4ontime = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            calendar = Calendar.getInstance();
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minutes = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(sched.this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                    if (hourOfDay >= 12) {
                        amPm = "PM";
                    } else {
                        amPm = "AM";
                    }
                    time = hourOfDay + ":" + minutes;
                    final SimpleDateFormat sdf = new SimpleDateFormat("H:mm");
                    final Date dateObj;
                    try {
                        dateObj = sdf.parse(time);
                        time1 = (new SimpleDateFormat("K:mm").format(dateObj));
                        light4ontimevalue.setText(aTime);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }
            }, hour, minutes, false);

            timePickerDialog.show();
        }
    };
    View.OnClickListener setlight4offtime = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            calendar = Calendar.getInstance();
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minutes = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(sched.this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                    hour = hourOfDay;
                    minutes = minutes;
                    String timeSet = "";
                    if (hour > 12) {
                        hour -= 12;
                        timeSet = "PM";
                    } else if (hour == 0) {
                        hour += 12;
                        timeSet = "AM";
                    } else if (hour == 12){
                        timeSet = "PM";
                    }else{
                        timeSet = "AM";
                    }

                    String min = "";
                    if (minutes < 10)
                        min = "0" + minutes ;
                    else
                        min = String.valueOf(minutes);

                    // Append in a StringBuilder
                    aTime = new StringBuilder().append(hour).append(':')
                            .append(min ).append(" ").append(timeSet).toString();
                        light4offtimevalue.setText(aTime);

                }
            }, hour, minutes, false);

            timePickerDialog.show();
        }
    };


    View.OnClickListener refreshClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
          /*  new getontimepump().execute();
            new getofftimepump().execute();
            new getfirsttimefishfeed().execute();
            new getsecondtimefishfeed().execute();
            new getamountfishfeed().execute();*/
            final String topic = "$aws/things/farm1/shadow/get/accepted";

            Log.d(LOG_TAG, "topic = " + topic);

            try {
                mqttManager.subscribeToTopic(topic, AWSIotMqttQos.QOS0,
                        new AWSIotMqttNewMessageCallback() {
                            @Override
                            public void onMessageArrived(final String topic, final byte[] data) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            String message = new String(data, "UTF-8");

                                            Log.d(LOG_TAG, "Message arrived:");
                                            Log.d(LOG_TAG, "   Topic: " + topic);
                                            Log.d(LOG_TAG, " Message: " + message);
                                            try {
                                                // get JSONObject from JSON file
                                                JSONObject obj = new JSONObject(message);
                                                // fetch JSONObject named employee
                                                JSONObject state = obj.getJSONObject("state");
                                                JSONObject desired = state.getJSONObject("desired");
                                                getstateontimepump = desired.getString("Ontime");
                                                getstateofftimepump = desired.getString("Offtime");
                                                getstatefirstfeed = desired.getString("Time1");
                                                getstatesecondfeed = desired.getString("Time2");
                                                getstateamount = desired.getString("Amount");

                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }

                                            pumpontimevalue.setText(getstateontimepump);
                                            pumpofftimevalue.setText(getstateofftimepump);
                                            firstfeedtimevalue.setText(getstatefirstfeed);
                                            secondfeedtimevalue.setText(getstatesecondfeed);
                                            amountoffeedvalue.setText(getstateamount);

                                        } catch (UnsupportedEncodingException e) {
                                            Log.e(LOG_TAG, "Message encoding error.", e);
                                        }
                                    }
                                });
                            }
                        });
            } catch (Exception e) {
                Log.e(LOG_TAG, "Subscription error.", e);
            }

            final String topicpub = "$aws/things/farm1/shadow/get";
            final String msg = String.format("");

            try {
                mqttManager.publishString(msg, topicpub, AWSIotMqttQos.QOS0);
            } catch (Exception e) {
                Log.e(LOG_TAG, "Publish error.", e);
            }
        }
    };
    View.OnClickListener refresh1Click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            /*new getontimelight1().execute();
            new getofftimelight1().execute();
            new getontimelight2().execute();
            new getofftimelight2().execute();*/
            final String topic = "$aws/things/farm1/shadow/get/accepted";

            Log.d(LOG_TAG, "topic = " + topic);

            try {
                mqttManager.subscribeToTopic(topic, AWSIotMqttQos.QOS0,
                        new AWSIotMqttNewMessageCallback() {
                            @Override
                            public void onMessageArrived(final String topic, final byte[] data) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            String message = new String(data, "UTF-8");

                                            Log.d(LOG_TAG, "Message arrived:");
                                            Log.d(LOG_TAG, "   Topic: " + topic);
                                            Log.d(LOG_TAG, " Message: " + message);
                                            try {
                                                // get JSONObject from JSON file
                                                JSONObject obj = new JSONObject(message);
                                                // fetch JSONObject named employee
                                                JSONObject state = obj.getJSONObject("state");
                                                JSONObject desired = state.getJSONObject("desired");
                                                getstateonlight1 = desired.getString("Ontimelight1");
                                                getstateofflight1 = desired.getString("Offtimelight1");
                                                getstateonlight2 = desired.getString("Ontimelight2");
                                                getstateofflight2 = desired.getString("Offtimelight2");


                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }

                                            light1ontimevalue.setText(getstateonlight1);
                                            light1offtimevalue.setText(getstateofflight1);
                                            light2ontimevalue.setText(getstateonlight2);
                                            light2offtimevalue.setText(getstateofflight2);


                                        } catch (UnsupportedEncodingException e) {
                                            Log.e(LOG_TAG, "Message encoding error.", e);
                                        }
                                    }
                                });
                            }
                        });
            } catch (Exception e) {
                Log.e(LOG_TAG, "Subscription error.", e);
            }

            final String topicpub = "$aws/things/farm1/shadow/get";
            final String msg = String.format("");

            try {
                mqttManager.publishString(msg, topicpub, AWSIotMqttQos.QOS0);
            } catch (Exception e) {
                Log.e(LOG_TAG, "Publish error.", e);
            }
        }
    };
    View.OnClickListener refresh2Click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            /*new getontimelight3().execute();
            new getofftimelight3().execute();
            new getontimelight4().execute();
            new getofftimelight4().execute();*/
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        //Check internet connection
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(broadcastReceiver, filter);
        Log.d(LOG_TAG, "clientId = " + clientId);

        try {
            mqttManager.connect(credentialsProvider, new AWSIotMqttClientStatusCallback() {
                @Override
                public void onStatusChanged(final AWSIotMqttClientStatus status,
                                            final Throwable throwable) {
                    Log.d(LOG_TAG, "Status = " + String.valueOf(status));

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (status == AWSIotMqttClientStatus.Connecting) {
                                Toast.makeText(getApplicationContext(),"Connecting...",Toast.LENGTH_SHORT).show();
                            } else if (status == AWSIotMqttClientStatus.Connected) {
                                Toast.makeText(getApplicationContext(),"Connected",Toast.LENGTH_SHORT).show();

                            } else if (status == AWSIotMqttClientStatus.Reconnecting) {
                                if (throwable != null) {
                                    Log.e(LOG_TAG, "Connection error.", throwable);
                                }
                                Toast.makeText(getApplicationContext(),"Reconnecting",Toast.LENGTH_SHORT).show();
                            } else if (status == AWSIotMqttClientStatus.ConnectionLost) {
                                if (throwable != null) {
                                    Log.e(LOG_TAG, "Connection error.", throwable);
                                    throwable.printStackTrace();
                                }
                                Toast.makeText(getApplicationContext(),"Disconnected",Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getApplicationContext(),"Disconnected",Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            });
        } catch (final Exception e) {
            Log.e(LOG_TAG, "Connection error.", e);
            Toast.makeText(getApplicationContext(),"Error! " + e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(broadcastReceiver);
    }





}
