package com.example.sample;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class broadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        if(ConnectivityManager.CONNECTIVITY_ACTION.equals(intent.getAction())){
           boolean noconnectivity = intent.getBooleanExtra(
                   ConnectivityManager.EXTRA_NO_CONNECTIVITY,false
           );
           if(noconnectivity){

               Toast.makeText(context, "No Connection", Toast.LENGTH_SHORT).show();
           }

         else{

               //Toast.makeText(context, "Internet Available", Toast.LENGTH_SHORT).show();
           }
        }
    }
}
