package com.example.sample;

import android.content.Context;


import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.cognito.CognitoSyncManager;
import com.amazonaws.mobileconnectors.cognito.Dataset;
import com.amazonaws.mobileconnectors.cognito.DefaultSyncCallback;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;

public class ManagerClass {
    CognitoCachingCredentialsProvider credentialsProvider=null;
    CognitoSyncManager syncManager=null;

    public static AmazonDynamoDBClient dynamoDBClient=null;
    public static DynamoDBMapper dynamoDBMapper = null;

    public CognitoCachingCredentialsProvider getcredentials(Context context) {
// Initialize the Amazon Cognito credentials provider
        CognitoCachingCredentialsProvider credentialsProvider = new CognitoCachingCredentialsProvider(
                context,
                "us-west-2:cc7e8d4a-2ae2-41ff-be95-62e03a0f9c9f", // Identity pool ID
                Regions.US_WEST_2 // Region
        );
        syncManager=new CognitoSyncManager(context,Regions.US_WEST_2,credentialsProvider);
        Dataset dataset=syncManager.openOrCreateDataset("Mydataset");
        dataset.put("mykey","myvalue");

        dataset.synchronize((new DefaultSyncCallback()));
        return credentialsProvider;
    }
    public DynamoDBMapper initDynamoClient(CognitoCachingCredentialsProvider credentialsProvider){
        if(dynamoDBClient == null){
            dynamoDBClient = new AmazonDynamoDBClient(credentialsProvider);
            dynamoDBClient.setRegion(Region.getRegion(Regions.US_WEST_2));
            dynamoDBMapper = new DynamoDBMapper(dynamoDBClient);
        }
        return dynamoDBMapper;
    }

}
