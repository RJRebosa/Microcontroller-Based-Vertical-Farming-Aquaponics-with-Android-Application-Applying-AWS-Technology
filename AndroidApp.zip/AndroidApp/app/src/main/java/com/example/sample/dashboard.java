package com.example.sample;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;

public class dashboard extends AppCompatActivity {

    private LinearLayout l1,l2,l3,l4,l5,l6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        l1 = (LinearLayout) findViewById(R.id.linear1);
        l2 = (LinearLayout) findViewById(R.id.linear2);
        l3 = (LinearLayout) findViewById(R.id.linear3);
        l4 = (LinearLayout) findViewById(R.id.linear4);
        l5 = (LinearLayout) findViewById(R.id.linear5);
        l6 = (LinearLayout) findViewById(R.id.linear6);
        l1.setOnClickListener(openFishtank);
        l2.setOnClickListener(openfarm1);
        l3.setOnClickListener(openreports);
        l4.setOnClickListener(openfarm2);
        l5.setOnClickListener(openinfo);
        l6.setOnClickListener(opensched);

    }

    View.OnClickListener openFishtank = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(dashboard.this, fishtank.class);
            startActivity(i);
        }
    };
    View.OnClickListener openfarm1 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(dashboard.this, farm1.class);
            startActivity(i);
        }
    };
    View.OnClickListener openfarm2 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(dashboard.this, farm2.class);
            startActivity(i);
        }
    };
    View.OnClickListener openreports = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent browserintent=new Intent(Intent.ACTION_VIEW, Uri.parse("https://us-west-2.console.aws.amazon.com/dynamodb/home?region=us-west-2#tables:selected=finalthesisdbtable;tab=items"));
            //Intent browserintent = new Intent(dashboard.this, reports.class);
            startActivity(browserintent);
        }
    };
    View.OnClickListener openinfo = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(dashboard.this, info.class);
            startActivity(i);
        }
    };
    View.OnClickListener opensched = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(dashboard.this, sched.class);
            startActivity(i);
        }
    };
    public void openAWSDynamo(View view){

    }

}
