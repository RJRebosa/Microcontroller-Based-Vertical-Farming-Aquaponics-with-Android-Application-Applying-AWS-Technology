package com.example.sample;

import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttClientStatusCallback;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttManager;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttNewMessageCallback;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttQos;
import com.amazonaws.regions.Regions;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.UUID;

//import androidx.appcompat.app.AppCompatActivity;


public class farm2 extends AppCompatActivity {

broadcastReceiver broadcastReceiver = new broadcastReceiver();

    //from pubsub
    static final String LOG_TAG = farm2.class.getCanonicalName();
    // --- Constants to modify per your configuration ---
    // Customer specific IoT endpoint
    // AWS Iot CLI describe-endpoint call returns: XXXXXXXXXX.iot.<region>.amazonaws.com,
    private static final String CUSTOMER_SPECIFIC_ENDPOINT = "a2r53qtneah6m2-ats.iot.us-west-2.amazonaws.com";

    // Cognito pool ID. For this app, pool needs to be unauthenticated pool with
    // AWS IoT permissions.
    private static final String COGNITO_POOL_ID = "us-west-2:cc7e8d4a-2ae2-41ff-be95-62e03a0f9c9f";

    // Region of AWS IoT
    private static final Regions MY_REGION = Regions.US_WEST_2;


    private Button backbtn,connectbtn,disconnectbtn,refresh;
    private android.widget.Switch repeller,light1,light2;
    private TextView tempvaluetxt, humvaluetxt, tvStatus;
    AWSIotMqttManager mqttManager;
    String clientId;

    String gettemp,gethum, getstaterepeller1;
    String pestrepeller = "Repeller";
    String growlight1 = "Light1";
    String growlight2 = "Light2";
    //Handler mHandler = new Handler();
    CognitoCachingCredentialsProvider credentialsProvider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farm2);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //refresh = (Button) findViewById(R.id.refresh);
        //refresh.setOnClickListener(refreshClick);
        tempvaluetxt = (TextView) findViewById(R.id.tempvaluetxt);
        humvaluetxt = (TextView) findViewById(R.id.humvaluetxt);
        tvStatus = (TextView) findViewById(R.id.tvStatus);
        repeller =(android.widget.Switch) findViewById(R.id.repeller);
        light1 =(Switch) findViewById(R.id.light1);
        light2 =(Switch) findViewById(R.id.light2);
        backbtn = (Button) findViewById(R.id.backbtn);
        backbtn.setOnClickListener(backClick);
        connectbtn = (Button) findViewById(R.id.connectbtn);
        connectbtn.setOnClickListener(connectClick);
        connectbtn.setEnabled(false);
        disconnectbtn = (Button) findViewById(R.id.disconnectbtn);
        disconnectbtn.setOnClickListener(disconnectClick);

        // MQTT client IDs are required to be unique per AWS IoT account.
        // This UUID is "practically unique" but does not _guarantee_
        // uniqueness.
        clientId = UUID.randomUUID().toString();
        // Initialize the AWS Cognito credentials provider
        credentialsProvider = new CognitoCachingCredentialsProvider(
                getApplicationContext(), // context
                COGNITO_POOL_ID, // Identity Pool ID
                MY_REGION // Region
        );
        // MQTT Client
        mqttManager = new AWSIotMqttManager(clientId, CUSTOMER_SPECIFIC_ENDPOINT);
        // The following block uses a Cognito credentials provider for authentication with AWS IoT.

                connectbtn.setEnabled(true);
        /*Thread mythread = new Thread(mHandlerTask);
        mythread.start();*/


    }//end of onCreate

    View.OnClickListener disconnectClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                mqttManager.disconnect();
            } catch (Exception e) {
                Log.e(LOG_TAG, "Disconnect error.", e);
            }

        }
    };
    View.OnClickListener connectClick = new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Log.d(LOG_TAG, "clientId = " + clientId);

                    try {
                        mqttManager.connect(credentialsProvider, new AWSIotMqttClientStatusCallback() {
                            @Override
                            public void onStatusChanged(final AWSIotMqttClientStatus status,
                                                        final Throwable throwable) {
                                Log.d(LOG_TAG, "Status = " + String.valueOf(status));

                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (status == AWSIotMqttClientStatus.Connecting) {
                                            tvStatus.setText("Connecting...");
                                            tvStatus.setTextColor(Color.parseColor("#4CAF50"));

                                        } else if (status == AWSIotMqttClientStatus.Connected) {
                                            tvStatus.setText("Connected");
                                            tvStatus.setTextColor(Color.parseColor("#4CAF50"));
                                            final String topic = "alldatafarm2";

                                            Log.d(LOG_TAG, "topic = " + topic);

                                            try {
                                                mqttManager.subscribeToTopic(topic, AWSIotMqttQos.QOS0,
                                                        new AWSIotMqttNewMessageCallback() {
                                                            @Override
                                                            public void onMessageArrived(final String topic, final byte[] data) {
                                                                runOnUiThread(new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        try {
                                                                            String message = new String(data, "UTF-8");
                                                                            Log.d(LOG_TAG, "Message arrived:");
                                                                            Log.d(LOG_TAG, "   Topic: " + topic);
                                                                            Log.d(LOG_TAG, " Message: " + message);
                                                                            try{
                                                                                // get JSONObject from JSON file
                                                                                JSONObject obj = new JSONObject(message);
                                                                                // fetch JSONObject named employee
                                                                                //JSONObject state = obj.getJSONObject("state");
                                                                                JSONObject desired = obj.getJSONObject("data");
                                                                                gettemp = desired.getString("temperature");
                                                                                gethum  = desired.getString("humidity");
                                                                            }
                                                                            catch (JSONException e) {
                                                                                e.printStackTrace();
                                                                            }

                                                                            tempvaluetxt.setText(gettemp + "°C");
                                                                            humvaluetxt.setText(gethum + " %");


                                                                        } catch (UnsupportedEncodingException e) {
                                                                            Log.e(LOG_TAG, "Message encoding error.", e);
                                                                        }

                                                                    }
                                                                });
                                                            }
                                                        });
                                            } catch (Exception e) {
                                                Log.e(LOG_TAG, "Subscription error.", e);
                                            }

                                        } else if (status == AWSIotMqttClientStatus.Reconnecting) {
                                            if (throwable != null) {
                                                Log.e(LOG_TAG, "Connection error.", throwable);
                                            }
                                            tvStatus.setText("Reconnecting");
                                        } else if (status == AWSIotMqttClientStatus.ConnectionLost) {
                                            if (throwable != null) {
                                                Log.e(LOG_TAG, "Connection error.", throwable);
                                                throwable.printStackTrace();
                                            }
                                            tvStatus.setText("Disconnected");
                                            tvStatus.setTextColor(Color.parseColor("#F3144E"));

                                        } else {
                                            tvStatus.setText("Disconnected");
                                            tvStatus.setTextColor(Color.parseColor("#F3144E"));

                                        }
                                    }
                                });
                            }
                        });
                    } catch (final Exception e) {
                        Log.e(LOG_TAG, "Connection error.", e);
                        tvStatus.setText("Error! " + e.getMessage());
                    }
                }
            };


    View.OnClickListener refreshClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

          // new getstaterepeller().execute();
//            new getstatelight1().execute();
//            new getstatelight2().execute();
        }
    };
    View.OnClickListener backClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(farm2.this, dashboard.class);
            startActivity(intent);
            //stopRepeatingTask();

        }
    };
    @Override
    protected void onStart() {
        super.onStart();
        //Check internet connection
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(broadcastReceiver, filter);

    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(broadcastReceiver);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //stopRepeatingTask();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();


    }
   /* void startRepeatingTask()
    {
         mHandlerTask.run();
    }
    void stopRepeatingTask()
    {
        mHandler.removeCallbacks(mHandlerTask);

    }*/
    /*Runnable mHandlerTask = new Runnable()
    {
        @Override
        public void run() {
            new farm2.getstaterepeller().execute();
            new farm2.getstatelight1().execute();
            new farm2.getstatelight2().execute();
            mHandler.postDelayed(mHandlerTask, 1000);
        }
    };*/





//    private class getstaterepeller extends AsyncTask<Void, Integer, Integer> {
//
//        @Override
//        protected Integer doInBackground(Void... voids) {
//            ManagerClass managerClass = new ManagerClass();
//            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(farm2.this);
//            mapperfarm2state mapperfarm2state = new mapperfarm2state();
//
//            DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
//
//            if (credentialsProvider != null && mapperfarm2state != null) {
//                DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
//                try{
//
//
//                    PaginatedScanList<com.example.sample.mapperfarm2state> result = dynamoDBMapper.scan(mapperfarm2state.class, scanExpression);
//                    //getstaterepeller1 = mapperfarm2state.getState();
//                    System.out.println(result.toString());
//                    //Toast.makeText(farm2.this, result.toString(), Toast.LENGTH_SHORT).show();
//                }catch (AmazonServiceException e){
//                    Toast.makeText(farm2.this, e.toString(), Toast.LENGTH_SHORT).show();
//                }
//                catch (AmazonClientException e){
//                    Toast.makeText(farm2.this, e.toString(), Toast.LENGTH_SHORT).show();
//                }
//            } else {
//                return 2;
//            }
//            return 1;
//        }
//
//
//        @Override
//        protected void onPostExecute(Integer integer) {
//            super.onPostExecute(integer);
//
//            if (integer == 1) {
//
//                //if (getstaterepeller1.equals("Off")) {
//                    //repeller.setChecked(false);
//                //}
//                //else if(getstaterepeller1.equals("On")){
//                    //repeller.setChecked(true);
//               // }
//            }
//        }
//  }
//    private class getstatelight1 extends AsyncTask<Void, Integer, Integer> {
//
//        @Override
//        protected Integer doInBackground(Void... voids) {
//            ManagerClass managerClass = new ManagerClass();
//            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(farm2.this);
//            mapperfarm2state mapperfarm2state = new mapperfarm2state();
//
//
//            if (credentialsProvider != null && mapperfarm2state != null) {
//                DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
//                try{
//                    mapperfarm2state = dynamoDBMapper.load(mapperfarm2state.class, growlight1);
//                    getstatelight1 = mapperfarm2state.getState();
//                }catch (AmazonServiceException e){
//                    Toast.makeText(farm2.this, e.toString(), Toast.LENGTH_SHORT).show();
//                }
//                catch (AmazonClientException e){
//                    Toast.makeText(farm2.this, e.toString(), Toast.LENGTH_SHORT).show();
//                }
//            } else {
//                return 2;
//            }
//            return 1;
//        }


//        @Override
//        protected void onPostExecute(Integer integer) {
//            super.onPostExecute(integer);
//
//            if (integer == 1) {
//                if (getstatelight1.equals("Off")) {
//                    light1.setChecked(false);
//                }
//                else if(getstatelight1.equals("On")){
//                    light1.setChecked(true);
//                }
//            }
//
//        }
//
//    }
//    private class getstatelight2 extends AsyncTask<Void, Integer, Integer> {
//
//        @Override
//        protected Integer doInBackground(Void... voids) {
//            ManagerClass managerClass = new ManagerClass();
//            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(farm2.this);
//            mapperfarm2state mapperfarm2state = new mapperfarm2state();
//
//
//            if (credentialsProvider != null && mapperfarm2state != null) {
//                DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
//                try{
//                    mapperfarm2state = dynamoDBMapper.load(mapperfarm2state.class, growlight2);
//                    getstatelight2 = mapperfarm2state.getState();
//                }catch (AmazonServiceException e){
//                    Toast.makeText(farm2.this, e.toString(), Toast.LENGTH_SHORT).show();
//                }
//                catch (AmazonClientException e){
//                    Toast.makeText(farm2.this, e.toString(), Toast.LENGTH_SHORT).show();
//                }
//            } else {
//                return 2;
//            }
//            return 1;
//        }
//
//
//        @Override
//        protected void onPostExecute(Integer integer) {
//            super.onPostExecute(integer);
//
//            if (integer == 1) {
//                if (getstatelight2.equals("Off")) {
//                    light2.setChecked(false);
//                }
//                else if(getstatelight2.equals("On")){
//                    light2.setChecked(true);
//                }
//            }
//
//        }
//
//    }


}

