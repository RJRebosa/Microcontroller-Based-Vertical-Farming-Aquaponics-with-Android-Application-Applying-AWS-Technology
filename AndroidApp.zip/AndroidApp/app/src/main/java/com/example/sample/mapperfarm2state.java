package com.example.sample;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

@DynamoDBTable(tableName = "farm2statetable")
public class mapperfarm2state {
    String Id;
    String Ontime,Offtime;

    @DynamoDBHashKey(attributeName="Id")
    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    @DynamoDBAttribute(attributeName="Ontime")
    public String getOntime() {
        return Ontime;
    }

    public void setOntime(String Ontime) {
        this.Ontime = Ontime;
    }
    @DynamoDBAttribute(attributeName="Offtime")
    public String getOfftime() {
        return Offtime;
    }

    public void setOfftime(String Offtime) {
        this.Offtime = Offtime;
    }
}

