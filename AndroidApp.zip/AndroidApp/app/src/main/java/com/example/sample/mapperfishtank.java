package com.example.sample;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

@DynamoDBTable(tableName = "finalthesisdbtable")
public class mapperfishtank {

    String id;
    String Ontime;
    String Offtime;
    String amount,firsttime,secondtime;

    @DynamoDBHashKey(attributeName="id")
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @DynamoDBAttribute(attributeName="OnTime")
    public String getOnTime() {
        return Ontime;
    }

    public void setOnTime(String OnTime) {
        this.Ontime = OnTime;
    }
    @DynamoDBAttribute(attributeName="OffTime")
    public String getOfftime() {
        return Offtime;
    }

    public void setOfftime(String OffTime) {
        this.Offtime = OffTime;
    }
    @DynamoDBAttribute(attributeName="AmountofFeeds")
    public String getAmount() {
        return amount;
    }

    public void setAmount(String AmountofFeeds) {
        this.amount = AmountofFeeds;
    }
    @DynamoDBAttribute(attributeName="firsttime")
    public String getFirsttime() {
        return firsttime;
    }

    public void setFirsttime(String firsttime) {
        this.firsttime = firsttime;
    }
    @DynamoDBAttribute(attributeName="secondtime")
    public String getSecondtime() {
        return secondtime;
    }

    public void setSecondtime(String secondtime) {
        this.secondtime = secondtime;
    }
}
