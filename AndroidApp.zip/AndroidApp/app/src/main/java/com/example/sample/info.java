package com.example.sample;

import android.app.Dialog;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

//import androidx.appcompat.app.AppCompatActivity;
public class info extends AppCompatActivity {
    //wifi
    broadcastReceiver broadcastReceiver = new broadcastReceiver();
    Dialog dialog;
    LinearLayout lettuce, kale, spinach, arugula, bokchoy, mint, chives, basil, cilantro, parsley, rosemary, thyme, swisschard, strawberries, beans, peppers, cucumbers;
    TextView infotxt, txt0, txt1, txt2, txt3, txt4, txt5, txt6, txt7, txt8, txt9;
    ImageView exitbtn;
    private TextToSpeech mTTS;
    public String basiltxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        mTTS = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = mTTS.setLanguage(Locale.GERMAN);

                    if (result == TextToSpeech.LANG_MISSING_DATA
                            || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("TTS", "Language not supported");
                    } else {
                    }
                } else {
                    Log.e("TTS", "Initialization failed");
                }
            }
        });
//error start
        dialog = new Dialog(this);
        lettuce = (LinearLayout) findViewById(R.id.linear1);
        lettuce.setOnClickListener(openLettuce);
        kale = (LinearLayout) findViewById(R.id.linear2);
        kale.setOnClickListener(openKale);
        spinach = (LinearLayout) findViewById(R.id.linear3);
        spinach.setOnClickListener(openSpinach);
       arugula = (LinearLayout) findViewById(R.id.linear4);
        arugula.setOnClickListener(openArugula);
        bokchoy = (LinearLayout) findViewById(R.id.linear5);
        bokchoy.setOnClickListener(openBokchoy);
       mint = (LinearLayout) findViewById(R.id.linear6);
        mint.setOnClickListener(openMint);
        chives = (LinearLayout) findViewById(R.id.linear7);
        chives.setOnClickListener(openChives);
        basil = (LinearLayout) findViewById(R.id.linear8);
        basil.setOnClickListener(openBasil);
        cilantro = (LinearLayout) findViewById(R.id.linear9);
        cilantro.setOnClickListener(openCilantro);
        parsley = (LinearLayout) findViewById(R.id.linear10);
        parsley.setOnClickListener(openParsley);
       rosemary = (LinearLayout) findViewById(R.id.linear11);
        rosemary.setOnClickListener(openRosemary);
       thyme = (LinearLayout) findViewById(R.id.linear12);
        thyme.setOnClickListener(openThyme);
       swisschard = (LinearLayout) findViewById(R.id.linear13);
        swisschard.setOnClickListener(openSwisschard);
        strawberries = (LinearLayout) findViewById(R.id.linear14);
        strawberries.setOnClickListener(openStrawberries);
       beans = (LinearLayout) findViewById(R.id.linear15);
        beans.setOnClickListener(openBeans);
       peppers = (LinearLayout) findViewById(R.id.linear16);
        peppers.setOnClickListener(openPeppers);
        cucumbers = (LinearLayout) findViewById(R.id.linear17);
        cucumbers.setOnClickListener(openCucumbers);
    }

    public void arugula(View v){
        Toast.makeText(this, "Arugula", Toast.LENGTH_SHORT).show();
            String text = "A delicious peppery leafy green vegetable, arugula is found in the mustard family and is another plant well suited for indoor aquaponics. Found in a wide range of salad mixes, it's perfect sprinkled on pizza, sandwiches, or straight off the plant. Ideal Parameters, pH level, six to seven, plant spacing, seven to ten centimeters, germination time and temperature, five to seven days, twenty to twenty five degrees celsius, growth time, twenty four to thirty two days, temperature, ten to twenty five degrees celsius, light exposure, full sun, plant height and width, fifteen to thirty centimeters, thirty to forty five centimeters";
            float pitch = 1.5f;
            //if (pitch < 0.1) pitch = 0.1f;
            float speed = 0.9f;
            //if (speed < 0.1) speed = 0.1f;

            mTTS.setPitch(pitch);
            mTTS.setSpeechRate(speed);

            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };
    public void thyme(View v){
        Toast.makeText(this, "Thyme", Toast.LENGTH_SHORT).show();
        String text = "This subtle, woodsy flavored herb goes deliciously with a variety of foods including meat, potatoes, and stews. It grows very quickly in an aquaponic system and smells wonderful! Ideal Parameters, pH, six to seven, Plant spacing, fifteen to thirty centimeters, Germination time and temperature, fourteen to twenty eight degrees Celsius, Growth time, twenty to thirty days after transplant, Temperature, fifteen to twenty five, Light exposure, full sun,Plant height and width, thirty to sixty centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };

    public void swisschard(View v){
        Toast.makeText(this, "Swisschard", Toast.LENGTH_SHORT).show();
        String text = "Swiss chard is an extremely popular leafy\n" +
                "green vegetable to grow using aquaponics and it thrives with all three aquaponic\n" +
                "methods. It is a moderate nitrate feeder and requires lower concentrations of potassium\n" +
                "and phosphorus than fruiting vegetables, which makes it an ideal plant for aquaponics. Ideal Parameters, pH,  six to seven, Plant spacing, twenty to thirty centimeters, Germination time and temperature, four to five days, twenty five to thirty degrees celsius optimal, Growth time, twenty five to thirty five days, Temperature, sixteen to twenty four degrees celsius, Light exposure, full sun,Plant height and width, thirty to sixty centimeters, thirty to forty centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };

    public void strawberries(View v){
        Toast.makeText(this, "Strawberries", Toast.LENGTH_SHORT).show();
        String text = "Strawberries actually prefer cooler temperatures which is why you don’t generally see strawberries growing in the desert. Although, if you do live in a hot climate, you could try growing the strawberries in the cooler winter months. Ideal Parameters, pH, five point five to six point five, Plant spacing, thirty to sixty centimeters, Germination time and temperature, three to seven days, twenty to thirty degrees celsius, Growth time, fifty five to sixty five days, Temperature, twenty two to twenty eight degrees celsius at day, eighteen to twenty degrees celsius at night, Light exposure, full sun, Plant height and width, twenty to two hundres centimeters, twenty to eighty centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };

    public void spinach(View v){
        Toast.makeText(this, "Spinach", Toast.LENGTH_SHORT).show();
        String text = "Spinach is a leafy green flowering plant native to central and western Asia. It is of the order Caryophyllales, family Amaranthaceae, subfamily Chenopodioideae. Its leaves are a common edible vegetable consumed either fresh, or after storage using preservation techniques by canning, freezing, or dehydration. Ideal Parameters, pH, five to seven, Plant spacing seven to twelve centimeters, Germination time and temperature, five to nine days, fifteen to twenty three degrees celsius,Growth time, twenty four to forty six days, Temperature, fifteen to twenty two degrees celsius, Light exposure, full sun, Plant height and width, twenty to ninety one centimeters, twenty five to thirty five centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };
    public void rosemary(View v){
        Toast.makeText(this, "Rosemary", Toast.LENGTH_SHORT).show();
        String text = "is a fragrant evergreen herb native to the Mediterranean. It is used as a culinary condiment, to make bodily perfumes, and for its potential health benefits. Ideal Parameters, pH, six to seven, Plant spacing, forty five to sixty centimeters, Germination time and temperature, fifteen to twenty five days, twenty one to twenty seven degrees celsius, Growth time, twenty four to forty six days, Temperature, twenty one to thirty degrees celsius, Light exposure, full sun, Plant height and width, ninety one to one hundred twenty one centimeters, fifty to ninety centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };
    public void peppers(View v){
        Toast.makeText(this, "Peppers", Toast.LENGTH_SHORT).show();
        String text = "There are many varieties of peppers, all varying\n" +
                "in colour and degree of spice, yet from the sweet bell pepper to the hot chili peppers\n" +
                "(jalapeño or cayenne peppers) they can all be grown with aquaponics. Ideal Parameters, pH, five point five to six point five, Plant spacing, thirty to sixty centimeters, Germination time and temperature, eight to twelve days, twenty two to thirty degrees celsius, Growth time, sixty to ninety five days, Temperature, fourteen to sixteen degrees celsius night time, twenty two to thirty degrees celsius daytime, Light exposure, full sun, Plant height and width, thirty to ninety centimeters, thirty to eighty centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };
    public void parsley(View v){
        Toast.makeText(this, "Parsley", Toast.LENGTH_SHORT).show();
        String text = "Parsley is a very common herb grown in both domestic and commercial aquaponic units owing to its nutritional content (rich in vitamins A and C,\n" +
                "calcium and iron) and its high market value. Ideal Parameters, pH: six to seven, Plant spacing, fifteen to thirty centimeters, Germination time and temperature, eight to ten days, twenty to twenty five degrees celsius, Growth time, twenty to thirty days after transplant, Temperature, fifteen to twenty five degrees celsius, Light exposure, full sun, Plant height and width, thirty to sixty centimeters, thirty to forty centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };
    public void mint(View v){
        Toast.makeText(this, "Mint", Toast.LENGTH_SHORT).show();
        String text = "The aromatic compounds in mint are pungent, refreshing, and unique. They also degrade pretty quickly, which means that mint has a limited shelf life. By the time a restaurant or bar receives mint, it’s usually lost that freshness. This makes freshly harvested mint a premium product that local farmers are equipped to supply! Once you’ve had freshly harvested mint, there’s no going back. Ideal Parameters, pH, six point five to seven, Plant spacing, forty five to sixty centimeters, Germination time and temperature, ten to fifteen days with temperatures at twenty to twenty three degrees celsius, Growth time, five to six weeks, Temperature, fifteen to twenty six degrees celsius, Light exposure, Sunny or slightly sheltered, Plant height and width, fifteen to thirty centimeters, thirty to one hundred twenty one centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };
    public void lettuce(View v){
        Toast.makeText(this, "Lettuce", Toast.LENGTH_SHORT).show();
        String text = "Lettuce grows particularly well in aquaponics\n" +
                "owing to the optimal nutrient concentrations in the water, Ideal Parameters, pH, six to seven, Plant spacing, eighteen to thirty centimeters, Germination time and temperature, three to seven days, thirteen to twenty one degrees celsius, Growth time, twenty four to thirty two days, Temperature, fifteen to twenty two degrees celsius, Light exposure, full sun, Plant height and width, twenty to thirty centimeters, twenty five to thirty five centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };
    public void kale(View v){
        Toast.makeText(this, "Kale", Toast.LENGTH_SHORT).show();
        String text = "Kale aquaponics is a great startup system. Not only is kale easy to grow it is exceptionally healthy for you. It is actually a form of cabbage in the Brassica family and is often considered to be one of the most powerful vegetables you can eat. Ideal Parameters, pH, six to seven point five, Plant spacing, eighteen to thirty centimeters, Germination time and temperature, five to seven days, fifteen to twenty three degrees celsius, Growth time, thirty to forty days, Temperature, fifteen to twenty two degrees celsius, Light exposure, full sun, Plant height and width, thirty to forty five centimeters, twenty five to thirty five centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };
    public void cucumbers(View v){
        Toast.makeText(this, "Cucumbers", Toast.LENGTH_SHORT).show();
        String text = "Cucumbers require a large quantities of nitrogen and potassium, thus the choice for the number of\n" +
                "plants should take into account the nutrients available in the water and the fish stocking\n" +
                "biomass. Ideal Parameters, pH, five point five to six point five, Plant spacing, thirty to sixty centimeters, Germination time and temperature, three to seven days, twenty to thirty degrees celsius, Growth time, fifty five to sixty five days, Temperature, twenty two to twenty eight degrees celsius day, eighteen to twenty degrees celsius night, Light exposure, full sun, Plant height and width, twenty to two hundred centimeters, twenty to eighty centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };
    public void cilantro(View v){
        Toast.makeText(this, "Cilantro", Toast.LENGTH_SHORT).show();
        String text = "While cilantro is an easy crop for soil gardeners, indoor and hydroponic growers may not get the highest space use efficiency from this crop. A longer turn and limited yield means that cilantro growers can see opportunity costs from growing something more productive. On the other hand, this herb is low-maintenance. If growers are sure that they can get good pricing, cilantro can still be a good crop. Ideal Parameters, pH, six point five to seven, Plant spacing, fifteen to thirty centimeters, Germination time and temperature, seven to ten days, twenty to twenty five degrees celsius, Growth time, thirty five to forty nine days, Temperature, fifteen to twenty five degrees celsius, Light exposure, full sun, Plant height and width, twenty to thirty centimeters, twenty five to thirty five centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };
    public void chives(View v){
        Toast.makeText(this, "Chives", Toast.LENGTH_SHORT).show();
        String text = "Chives are an incredibly versatile herb with a mild to strong onion flavor, depending on the growing conditions and variety. The great flavor, combined with the ease with which chives propagate and thrive, make them a popular ingredient and a great crop for aquaponic. Ideal Parameters, pH, six to seven, Plant spacing, eighteen to thirty centimeters, Germination time and temperature, eight to ten days, twenty to twenty five degrees celsius, Growth time, twenty four to forty eight days, Temperature, twenty to twenty six degrees celsius, Light exposure, full sun, Plant height and width, thirty to sixty centimeters, twenty five to thirty five centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };
    public void bokchoy(View v){
        Toast.makeText(this, "Bokckoy", Toast.LENGTH_SHORT).show();
        String text = "Also called Chinese cabbage, the plant grows on thick sweet stems, often with white veins running through dark leaves. Because of the thick water-heavy leaves, Bok Choy has a high water weight. This makes it a great choice for farmers with a market for it. Ideal Parameters, pH, six point five to seven, Plant spacing, eighteen to twenty five centimeters, Germination time and temperature, five to seven days, fifteen to twenty six degrees celsius, Growth time, thirty five to forty five days, Temperature, fifteen to twenty two degrees celsius, Light exposure, full sun, Plant height and width, thirty to forty five centimeters, twenty to thirty five centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };
    public void beans(View v){
        Toast.makeText(this, "Beans", Toast.LENGTH_SHORT).show();
        String text = "Both climbing and bush bean varieties grow well in aquaponic units, but the former are recommended for less use of space, which\n" +
                "maximizes aquaponic bed use. Ideal Parameters, pH, five point five to seven, Plant spacing, ten to thirty centimeters, Germination time and temperature, eight to ten days, twenty one to twenty six degrees celsius, Growth time, fifty to one hundred ten days, Temperature, sisteen to eighteen degrees celsius night, twenty two to twenty six degrees celsius day, Light exposure, full sun, Plant height and width, sixty to two hundred fifty centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };
    public void basil(View v){
        Toast.makeText(this, "Basil", Toast.LENGTH_SHORT).show();
        String text = "Basil is one of the most popular herbs to grow\n" +
                "in aquaponic units, particularly in large-scale commercial monoculture units because\n" +
                "of its high value and the high demand in urban or peri-urban zones. Ideal Parameters, pH, five point five to six point five, Plant spacing, fifteen to twenty five centimeters, Germination time and temperature, six to seven days with temperatures at twenty to twenty five degrees celsius, Growth time, five to six weeks, Temperature, eighteen to thirty degrees celsius, optimal twenty to twenty five degrees celsius, Light exposure, Sunny or slightly sheltered, Plant height and width, thirty to seventy centimeters, thirty centimeters";
        float pitch = 1.5f;
        //if (pitch < 0.1) pitch = 0.1f;
        float speed = 0.9f;
        //if (speed < 0.1) speed = 0.1f;

        mTTS.setPitch(pitch);
        mTTS.setSpeechRate(speed);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);

    };

    //error end
    @Override
    protected void onDestroy() {
        if (mTTS != null) {
            mTTS.stop();
            mTTS.shutdown();
        }

        super.onDestroy();
    }

/*
//click event
    */
View.OnClickListener openLettuce = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.lettuce);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };


    View.OnClickListener openKale = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.kale);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openSpinach = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.spinach);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openArugula = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.arugula);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openBokchoy = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.bokchoy);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openMint = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.mint);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openChives = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.chives);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openBasil = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.basil);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openCilantro = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.cilantro);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openParsley = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.parsley);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openRosemary = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.rosemary);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openThyme = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.thyme);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openSwisschard = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.swisschard);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openStrawberries = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.strawberries);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openBeans = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.beans);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openPeppers = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.peppers);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };
    View.OnClickListener openCucumbers = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setContentView(R.layout.cucumbers);
            exitbtn = (ImageView) dialog.findViewById(R.id.close);
            infotxt = (TextView) dialog.findViewById((R.id.infotitle));
            txt0 = (TextView) dialog.findViewById((R.id.txt0));
            txt1 = (TextView) dialog.findViewById((R.id.txt1));
            txt2 = (TextView) dialog.findViewById((R.id.txt2));
            txt3 = (TextView) dialog.findViewById((R.id.txt3));
            txt4 = (TextView) dialog.findViewById((R.id.txt4));
            txt5 = (TextView) dialog.findViewById((R.id.txt5));
            txt6 = (TextView) dialog.findViewById((R.id.txt6));
            txt7 = (TextView) dialog.findViewById((R.id.txt7));
            txt8 = (TextView) dialog.findViewById((R.id.txt8));
            txt9 = (TextView) dialog.findViewById((R.id.txt9));

            exitbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.show();
        }
    };


    @Override
    protected void onStart() {
        super.onStart();
        //Check internet connection
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(broadcastReceiver, filter);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(broadcastReceiver);
    }
    public void backbtn6(View v) {
        Intent intent = new Intent(info.this, fishtank.class);
        startActivity(intent);
    }
}
