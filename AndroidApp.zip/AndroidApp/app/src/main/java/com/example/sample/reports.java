package com.example.sample;

import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMappingException;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBScanExpression;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.PaginatedScanList;

//import android.support.v7.app.AppCompatActivity;
//import androidx.appcompat.app.AppCompatActivity;

public class reports extends AppCompatActivity {
    //private WebView webView;
    String getsensordata,setsensordata;
    TextView sensor;
    //wifi
    broadcastReceiver broadcastReceiver = new broadcastReceiver();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        sensor = (TextView) findViewById(R.id.textView9);
        new gettable().execute();

    }

    @Override
    protected void onStart() {
        super.onStart();
        //Check internet connection
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(broadcastReceiver, filter);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(broadcastReceiver);
    }
    public void backbtn4(View v) {
        Intent intent = new Intent(reports.this, fishtank.class);
        startActivity(intent);
    }


    private class gettable extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(reports.this);
            mapperfarm1 mapperfarm1 = new mapperfarm1();



            if (credentialsProvider != null && mapperfarm1 != null) {
                DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                try {
                    DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
                    PaginatedScanList<com.example.sample.mapperfarm1> result = dynamoDBMapper.scan(mapperfarm1.class, scanExpression);
                    for (mapperfarm1 Farm1 : result) {
                        //System.out.println(result.toString());
                        setsensordata = Farm1.toString();
                    }
                    //mapperfarm1 = dynamoDBMapper.load(mapperfarm1.class, getsensordata);
                   // setsensordata = mapperfarm1.getSensordata();
                }
                catch (DynamoDBMappingException e){
                }
                catch (final NullPointerException e){
                }
                return 1;
            }
            else {
                return 2;
            }
        }

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);

        sensor.setText(setsensordata);

        }
    }
}


