package com.example.sample;

import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMappingException;

//import androidx.appcompat.app.AppCompatActivity;
public class verticalfarming extends AppCompatActivity {

    //wifi
    broadcastReceiver broadcastReceiver = new broadcastReceiver();
    private EditText User;
    private EditText Password;
    private Button Login;

    String getuser, getpass, setuser, setpass;


    protected Button b1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_verticalfarming);

        User = (EditText) findViewById(R.id.et1);
        Password = (EditText) findViewById(R.id.et2);
        Login = (Button) findViewById(R.id.b1);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
try {
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            if(User.getText().equals(null) || !User.getText().equals("")) {
                getuser = User.getText().toString();
                getpass = Password.getText().toString();
                new gettable().execute();
            }
            //validate(User.getText().toString(), Password.getText().toString().toString());
        }
    });

}
catch (final NullPointerException e){
    new Handler(Looper.getMainLooper()).post(new Runnable() {
        @Override
        public void run() {
            Toast.makeText(verticalfarming.this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    });
}

            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        //Check internet connection
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(broadcastReceiver, filter);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(broadcastReceiver);
    }






public void regb(View v){
    Intent intent = new Intent(verticalfarming.this, Switch.class);
    startActivity(intent);
}
    private class gettable extends AsyncTask<Void, Integer, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(verticalfarming.this);
            mapperuser mapperuser = new mapperuser();



            if (credentialsProvider != null && mapperuser != null) {
                DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                try {


                        mapperuser = dynamoDBMapper.load(mapperuser.class, getuser);
                        setuser = mapperuser.getUsername();
                        setpass = mapperuser.getPassword();
                }
                catch (DynamoDBMappingException e){
                }
                catch (final NullPointerException e){
                }
                return 1;
                 }
            else {
                return 2;
            }
        }
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            try{
                if (integer == 1) {

                    if(getuser != "" || getuser != null) {
                        if (setuser.equals(getuser)) {
                            if (setpass.equals(getpass)) {
                                Intent i = new Intent(verticalfarming.this, fishtank.class);
                                startActivity(i);
                                Toast.makeText(verticalfarming.this, "Successful", Toast.LENGTH_SHORT).show();
                                finish();
                            } else {
                                Toast.makeText(verticalfarming.this, "Wrong Password", Toast.LENGTH_SHORT).show();
                            }

                        } else {
                            Toast.makeText(verticalfarming.this, "Wrong Password", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
            catch (NullPointerException e){
                Toast.makeText(verticalfarming.this, "Username don't exist", Toast.LENGTH_SHORT).show();
            }


}


    }
}


