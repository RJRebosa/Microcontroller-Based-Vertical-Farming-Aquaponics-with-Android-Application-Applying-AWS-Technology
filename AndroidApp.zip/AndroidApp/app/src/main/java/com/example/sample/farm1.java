package com.example.sample;

import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttClientStatusCallback;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttManager;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttNewMessageCallback;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttQos;
import com.amazonaws.regions.Regions;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.UUID;

//import android.support.v7.app.AppCompatActivity;
//import androidx.appcompat.app.AppCompatActivity;

public class farm1 extends AppCompatActivity  {

    //from pubsub
    static final String LOG_TAG = farm2.class.getCanonicalName();
    // --- Constants to modify per your configuration ---
    // Customer specific IoT endpoint
    // AWS Iot CLI describe-endpoint call returns: XXXXXXXXXX.iot.<region>.amazonaws.com,
    private static final String CUSTOMER_SPECIFIC_ENDPOINT = "a2r53qtneah6m2-ats.iot.us-west-2.amazonaws.com";

    // Cognito pool ID. For this app, pool needs to be unauthenticated pool with
    // AWS IoT permissions.
    private static final String COGNITO_POOL_ID = "us-west-2:cc7e8d4a-2ae2-41ff-be95-62e03a0f9c9f";

    // Region of AWS IoT
    private static final Regions MY_REGION = Regions.US_WEST_2;

    //wifi
    broadcastReceiver broadcastReceiver = new broadcastReceiver();
    private Button backbtn,connectbtn,disconnectbtn,refresh;
    private TextView tempvaluetxt, tvStatus,humvaluetxt;
    private Switch light1,light2,repeller;
    String getstateonlight1,getstaterepeller,getstateonlight2;
    AWSIotMqttManager mqttManager;
    String clientId;
    CognitoCachingCredentialsProvider credentialsProvider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farm1);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        light1 = (Switch) findViewById(R.id.light1);
        light1.setOnClickListener(changelight1);
        light2 = (Switch) findViewById(R.id.light2);
        light2.setOnClickListener(changelight2);
        repeller = (Switch) findViewById(R.id.repeller);
        repeller.setOnClickListener(changerepeller);
        refresh = (Button) findViewById(R.id.refresh);
        refresh.setOnClickListener(refreshClick);
        tempvaluetxt = (TextView) findViewById(R.id.tempvaluetxt);
        humvaluetxt = (TextView) findViewById(R.id.humvaluetxt);
        tvStatus = (TextView) findViewById(R.id.tvStatus);
        backbtn = (Button) findViewById(R.id.backbtn);
        backbtn.setOnClickListener(backClick);
        connectbtn = (Button) findViewById(R.id.connectbtn);
        connectbtn.setOnClickListener(connectClick);
        connectbtn.setEnabled(false);
        disconnectbtn = (Button) findViewById(R.id.disconnectbtn);
        disconnectbtn.setOnClickListener(disconnectClick);
        // MQTT client IDs are required to be unique per AWS IoT account.
        // This UUID is "practically unique" but does not _guarantee_
        // uniqueness.
        clientId = UUID.randomUUID().toString();
        // Initialize the AWS Cognito credentials provider
        credentialsProvider = new CognitoCachingCredentialsProvider(
                getApplicationContext(), // context
                COGNITO_POOL_ID, // Identity Pool ID
                MY_REGION // Region
        );
        // MQTT Client
        mqttManager = new AWSIotMqttManager(clientId, CUSTOMER_SPECIFIC_ENDPOINT);
        // The following block uses a Cognito credentials provider for authentication with AWS IoT.
        connectbtn.setEnabled(true);
    }

    public void getSpeechInput(View view) {

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, 10);
        } else {
            Toast.makeText(this, "Your Device Don't Support Speech Input", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 10:
                if (resultCode == RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    if(result.get(0).equals("light one on") || result.get(0).equals("Light one on") || result.get(0).equals("light 1 on")){

                        final String topic = "$aws/things/farm1/shadow/update";
                            final String msg = "{\n" +
                                    "\"state\": {\n" +
                                    "\"desired\": {\n" +
                                    "\"light1state\": \"true\"\n" +
                                    "}\n" +
                                    "}\n" +
                                    "}";
                            try {
                                mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                            } catch (Exception e) {
                                Log.e(LOG_TAG, "Publish error.", e);
                            }

                        Toast.makeText(this, "Light 1 turn on", Toast.LENGTH_SHORT).show();
                    }
                    else if(result.get(0).equals("light one off") || result.get(0).equals("light one of") || result.get(0).equals("light 1 off")){
                        final String topic = "$aws/things/farm1/shadow/update";
                            final String msg = "{\n" +
                                    "\"state\": {\n" +
                                    "\"desired\": {\n" +
                                    "\"light1state\": \"false\"\n" +
                                    "}\n" +
                                    "}\n" +
                                    "}";
                            try {
                                mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                            } catch (Exception e) {
                                Log.e(LOG_TAG, "Publish error.", e);
                            }

                        Toast.makeText(this, "Light 1 turn off", Toast.LENGTH_SHORT).show();
                    }
                    else if(result.get(0).equals("light two on") || result.get(0).equals("light 2 on") || result.get(0).equals("light to on")){
                        final String topic = "$aws/things/farm1/shadow/update";

                            final String msg = "{\n" +
                                    "\"state\": {\n" +
                                    "\"desired\": {\n" +
                                    "\"light2state\": \"true\"\n" +
                                    "}\n" +
                                    "}\n" +
                                    "}";
                            try {
                                mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                            } catch (Exception e) {
                                Log.e(LOG_TAG, "Publish error.", e);
                            }

                        Toast.makeText(this, "Light 2 turn on", Toast.LENGTH_SHORT).show();
                    }
                    else if(result.get(0).equals("light two off") || result.get(0).equals("light 2 of") || result.get(0).equals("light 2 off") || result.get(0).equals("light to off")){
                        final String topic = "$aws/things/farm1/shadow/update";

                            final String msg = "{\n" +
                                    "\"state\": {\n" +
                                    "\"desired\": {\n" +
                                    "\"light2state\": \"false\"\n" +
                                    "}\n" +
                                    "}\n" +
                                    "}";
                            try {
                                mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                            } catch (Exception e) {
                                Log.e(LOG_TAG, "Publish error.", e);
                            }

                        Toast.makeText(this, "Light 2 turn off", Toast.LENGTH_SHORT).show();
                    }
                    else if(result.get(0).equals("repeller on") || result.get(0).equals("propeller on")){
                        final String topic = "$aws/things/farm1/shadow/update";
                            final String msg = "{\n" +
                                    "\"state\": {\n" +
                                    "\"desired\": {\n" +
                                    "\"Repeller\": \"true\"\n" +
                                    "}\n" +
                                    "}\n" +
                                    "}";
                            try {
                                mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                            } catch (Exception e) {
                                Log.e(LOG_TAG, "Publish error.", e);
                            }
                        Toast.makeText(this, "Repeller turn on", Toast.LENGTH_SHORT).show();
                    }
                    else if(result.get(0).equals("repeller off") || result.get(0).equals("propeller off") || result.get(0).equals("propeller of")|| result.get(0).equals("repeller of")){
                        final String topic = "$aws/things/farm1/shadow/update";
                            final String msg = "{\n" +
                                    "\"state\": {\n" +
                                    "\"desired\": {\n" +
                                    "\"Repeller\": \"false\"\n" +
                                    "}\n" +
                                    "}\n" +
                                    "}";
                            try {
                                mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                            } catch (Exception e) {
                                Log.e(LOG_TAG, "Publish error.", e);
                            }
                        Toast.makeText(this, "Repeller turn off", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(this, "Command Unknown", Toast.LENGTH_SHORT).show();
                    }
                }
                break;
        }
    }

    View.OnClickListener refreshClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            //new fishtank.().execute();
            //new fishtank.getstatepump().execute();

                                            /*new getontimelight1().execute();
            new getofftimelight1().execute();
            new getontimelight2().execute();
            new getofftimelight2().execute();*/
            final String topic = "$aws/things/farm1/shadow/get/accepted";

            Log.d(LOG_TAG, "topic = " + topic);

            try {
                mqttManager.subscribeToTopic(topic, AWSIotMqttQos.QOS0,
                        new AWSIotMqttNewMessageCallback() {
                            @Override
                            public void onMessageArrived(final String topic, final byte[] data) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            String message = new String(data, "UTF-8");

                                            Log.d(LOG_TAG, "Message arrived:");
                                            Log.d(LOG_TAG, "   Topic: " + topic);
                                            Log.d(LOG_TAG, " Message: " + message);
                                            try {
                                                // get JSONObject from JSON file
                                                JSONObject obj = new JSONObject(message);
                                                // fetch JSONObject named employee
                                                JSONObject state = obj.getJSONObject("state");
                                                JSONObject desired = state.getJSONObject("desired");
                                                getstateonlight1 = desired.getString("light1state");
                                                getstateonlight2 = desired.getString("light2state");
                                                getstaterepeller = desired.getString("Repeller");



                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }

                                            if (getstateonlight1.equals("true")) {

                                                light1.setChecked(true);

                                            }
                                            else{

                                                light1.setChecked(false);
                                            }
                                            if (getstateonlight2.equals("true")) {
                                                light2.setChecked(true);

                                            }
                                            else{

                                                light2.setChecked(false);
                                            }
                                            if (getstaterepeller.equals("true")) {

                                                repeller.setChecked(true);

                                            }
                                            else{

                                                repeller.setChecked(false);
                                            }


                                        } catch (UnsupportedEncodingException e) {
                                            Log.e(LOG_TAG, "Message encoding error.", e);
                                        }
                                    }
                                });
                            }
                        });
            } catch (Exception e) {
                Log.e(LOG_TAG, "Subscription error.", e);
            }

            final String topicpub = "$aws/things/farm1/shadow/get";
            final String msg = String.format("");

            try {
                mqttManager.publishString(msg, topicpub, AWSIotMqttQos.QOS0);
            } catch (Exception e) {
                Log.e(LOG_TAG, "Publish error.", e);
            }
        }


    };
    View.OnClickListener disconnectClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                mqttManager.disconnect();
            } catch (Exception e) {
                Log.e(LOG_TAG, "Disconnect error.", e);
            }

        }
    };
    View.OnClickListener changelight1 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            final String topic = "$aws/things/farm1/shadow/update";
            if(light1.isChecked()== true){
                final String msg = "{\n" +
                        "\"state\": {\n" +
                        "\"desired\": {\n" +
                        "\"light1state\": \"true\"\n" +
                        "}\n" +
                        "}\n" +
                        "}";
                try {
                    mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                } catch (Exception e) {
                    Log.e(LOG_TAG, "Publish error.", e);
                }
            }
            else{
                final String msg = "{\n" +
                        "\"state\": {\n" +
                        "\"desired\": {\n" +
                        "\"light1state\": \"false\"\n" +
                        "}\n" +
                        "}\n" +
                        "}";
                try {
                    mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                } catch (Exception e) {
                    Log.e(LOG_TAG, "Publish error.", e);
                }
            }




        }
    };
    View.OnClickListener changelight2 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            final String topic = "$aws/things/farm1/shadow/update";
            if(light2.isChecked()== true){
                final String msg = "{\n" +
                        "\"state\": {\n" +
                        "\"desired\": {\n" +
                        "\"light2state\": \"true\"\n" +
                        "}\n" +
                        "}\n" +
                        "}";
                try {
                    mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                } catch (Exception e) {
                    Log.e(LOG_TAG, "Publish error.", e);
                }
            }
            else{
                final String msg = "{\n" +
                        "\"state\": {\n" +
                        "\"desired\": {\n" +
                        "\"light2state\": \"false\"\n" +
                        "}\n" +
                        "}\n" +
                        "}";
                try {
                    mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                } catch (Exception e) {
                    Log.e(LOG_TAG, "Publish error.", e);
                }
            }




        }
    };

    View.OnClickListener changerepeller = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            final String topic = "$aws/things/farm1/shadow/update";
            if(repeller.isChecked()== true){
                final String msg = "{\n" +
                        "\"state\": {\n" +
                        "\"desired\": {\n" +
                        "\"Repeller\": \"true\"\n" +
                        "}\n" +
                        "}\n" +
                        "}";
                try {
                    mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                } catch (Exception e) {
                    Log.e(LOG_TAG, "Publish error.", e);
                }
            }
            else{
                final String msg = "{\n" +
                        "\"state\": {\n" +
                        "\"desired\": {\n" +
                        "\"Repeller\": \"false\"\n" +
                        "}\n" +
                        "}\n" +
                        "}";
                try {
                    mqttManager.publishString(msg, topic, AWSIotMqttQos.QOS0);
                } catch (Exception e) {
                    Log.e(LOG_TAG, "Publish error.", e);
                }
            }




        }
    };
    View.OnClickListener connectClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            Log.d(LOG_TAG, "clientId = " + clientId);

            try {
                mqttManager.connect(credentialsProvider, new AWSIotMqttClientStatusCallback() {
                    @Override
                    public void onStatusChanged(final AWSIotMqttClientStatus status,
                                                final Throwable throwable) {
                        Log.d(LOG_TAG, "Status = " + String.valueOf(status));

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (status == AWSIotMqttClientStatus.Connecting) {
                                    tvStatus.setText("Connecting...");
                                    tvStatus.setTextColor(Color.parseColor("#4CAF50"));

                                } else if (status == AWSIotMqttClientStatus.Connected) {
                                    tvStatus.setText("Connected");
                                    tvStatus.setTextColor(Color.parseColor("#4CAF50"));
                                    final String topictemp = "farm1temp";
                                    final String topichum = "farm1hum";
                                    Log.d(LOG_TAG, "topic = " + topictemp);
                                    Log.d(LOG_TAG, "topic = " + topichum);

                                    try {
                                        mqttManager.subscribeToTopic(topictemp, AWSIotMqttQos.QOS0,
                                                new AWSIotMqttNewMessageCallback() {
                                                    @Override
                                                    public void onMessageArrived(final String topictemp, final byte[] data) {
                                                        runOnUiThread(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                try {
                                                                    String message = new String(data, "UTF-8");
                                                                    Log.d(LOG_TAG, "Message arrived:");
                                                                    Log.d(LOG_TAG, "   Topic: " + topictemp);
                                                                    Log.d(LOG_TAG, " Message: " + message);
                                                                    message = message.replaceAll("[^\\d.]", "");
                                                                    tempvaluetxt.setText(message + " °C");

                                                                } catch (UnsupportedEncodingException e) {
                                                                    Log.e(LOG_TAG, "Message encoding error.", e);
                                                                }
                                                            }
                                                        });
                                                    }
                                                });
                                    } catch (AmazonServiceException e){
                                        Log.e(LOG_TAG, "AmazonServiceException", e);
                                    }catch (AmazonClientException e){
                                        Log.e(LOG_TAG, "AmazonClientException", e);
                                    }
                                    catch (NullPointerException e){
                                        Log.e(LOG_TAG, "NullPointerException", e);
                                    }catch (Exception e) {
                                        Log.e(LOG_TAG, "Subscription error.", e);
                                    }
                                    try {
                                        mqttManager.subscribeToTopic(topichum, AWSIotMqttQos.QOS0,
                                                new AWSIotMqttNewMessageCallback() {
                                                    @Override
                                                    public void onMessageArrived(final String topichum, final byte[] data) {
                                                        runOnUiThread(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                try {
                                                                    String message = new String(data, "UTF-8");
                                                                    Log.d(LOG_TAG, "Message arrived:");
                                                                    Log.d(LOG_TAG, "   Topic: " + topichum);
                                                                    Log.d(LOG_TAG, " Message: " + message);

                                                                    message = message.replaceAll("[^\\d.]", "");
                                                                    humvaluetxt.setText(message + " %");

                                                                } catch (UnsupportedEncodingException e) {
                                                                    Log.e(LOG_TAG, "Message encoding error.", e);
                                                                }
                                                            }
                                                        });
                                                    }
                                                });
                                    } catch (AmazonServiceException e){
                                        Log.e(LOG_TAG, "AmazonServiceException", e);
                                    }catch (AmazonClientException e){
                                        Log.e(LOG_TAG, "AmazonClientException", e);
                                    }
                                    catch (NullPointerException e){
                                        Log.e(LOG_TAG, "NullPointerException", e);
                                    }catch (Exception e) {
                                        Log.e(LOG_TAG, "Subscription error.", e);
                                    }

                                } else if (status == AWSIotMqttClientStatus.Reconnecting) {
                                    if (throwable != null) {
                                        Log.e(LOG_TAG, "Connection error.", throwable);
                                    }
                                    tvStatus.setText("Reconnecting");
                                } else if (status == AWSIotMqttClientStatus.ConnectionLost) {
                                    if (throwable != null) {
                                        Log.e(LOG_TAG, "Connection error.", throwable);
                                        throwable.printStackTrace();
                                    }
                                    tvStatus.setText("Disconnected");
                                    tvStatus.setTextColor(Color.parseColor("#F3144E"));

                                } else {
                                    tvStatus.setText("Disconnected");
                                    tvStatus.setTextColor(Color.parseColor("#F3144E"));

                                }
                            }
                        });
                    }
                });
            } catch (final Exception e) {
                Log.e(LOG_TAG, "Connection error.", e);
                tvStatus.setText("Error! " + e.getMessage());
            }
        }
    };



    View.OnClickListener backClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(farm1.this, dashboard.class);
            startActivity(intent);
        }
    };

    public void reportf1(View v) {
        Intent intent = new Intent(farm1.this, reports.class);
        startActivity(intent);
    }
    @Override
    protected void onStart() {
        super.onStart();
        //Check internet connection
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(broadcastReceiver, filter);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(broadcastReceiver);
    }

    }
