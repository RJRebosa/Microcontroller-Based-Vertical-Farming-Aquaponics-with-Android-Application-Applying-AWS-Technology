package com.example.sample;

import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;

//import android.support.v7.app.AppCompatActivity;
//import androidx.appcompat.app.AppCompatActivity;

public class Switch extends AppCompatActivity {
    //wifi
    broadcastReceiver broadcastReceiver = new broadcastReceiver();
    private Button registerbtn;
    protected Button logout;
    private EditText User,Password;
    String signup = "Sign-Up Sucessfuly";
    String setname,setpass,getname,getpass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_switch);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        registerbtn = (Button) findViewById(R.id.sub);
        User = (EditText) findViewById(R.id.fnamae);
        Password = (EditText) findViewById(R.id.editText2);
        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getname = User.getText().toString();
                getpass = Password.getText().toString();
                new updatetable().execute();
            }
        });

    }
    @Override
    protected void onStart() {
        super.onStart();
        //Check internet connection
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(broadcastReceiver, filter);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(broadcastReceiver);
    }



    public void backbtn(View v) {
        Intent intent = new Intent(Switch.this, verticalfarming.class);
        startActivity(intent);
    }
    private class updatetable extends AsyncTask<Void,Integer,Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {
            ManagerClass managerClass = new ManagerClass();
            CognitoCachingCredentialsProvider credentialsProvider = managerClass.getcredentials(Switch.this);
            mapperuser mapperuser = new mapperuser();
            mapperuser.setUsername(getname);
            mapperuser.setPassword(getpass);
            if (credentialsProvider != null && mapperuser != null)
            {
                DynamoDBMapper dynamoDBMapper = managerClass.initDynamoClient(credentialsProvider);
                dynamoDBMapper.save(mapperuser);
            } else {
                return 2;
            }
            return 1;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            if(integer == 1){
                Toast.makeText(Switch.this,"Updated",Toast.LENGTH_SHORT).show();
                finish();
            }else if(integer == 2){
                Toast.makeText(Switch.this,"Failed",Toast.LENGTH_SHORT).show();
            }
        }
    }



}
